
import { useEffect, useRef, useState } from "react";
import "./AdminDashboard.css";

const API_URL = "http://127.0.0.1:8000";

function AdminDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  // Prevent multiple dashboard requests from running simultaneously
  const requestInProgress = useRef(false);

  async function fetchDashboard(isRefresh = false) {
    if (requestInProgress.current) {
      return;
    }

    requestInProgress.current = true;

    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      const token = localStorage.getItem("access_token");

      if (!token) {
        throw new Error("Please log in to access the admin dashboard.");
      }

      const response = await fetch(`${API_URL}/admin/dashboard`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "Unable to load dashboard data."
        );
      }

      setDashboard(data);
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
      setRefreshing(false);
      requestInProgress.current = false;
    }
  }

  // Initial load, automatic refresh and browser-tab focus refresh
  useEffect(() => {
    fetchDashboard();

    // Refresh dashboard every 5 seconds
    const interval = setInterval(() => {
      fetchDashboard(true);
    }, 5000);

    // Refresh when admin returns to this browser tab
    const handleFocus = () => {
      fetchDashboard(true);
    };

    window.addEventListener("focus", handleFocus);

    return () => {
      clearInterval(interval);
      window.removeEventListener("focus", handleFocus);
    };
  }, []);

  if (loading) {
    return (
      <div className="admin-dashboard admin-loading">
        <div className="admin-loader"></div>
        <h2>Loading your dashboard...</h2>
        <p>Getting the latest parking statistics</p>
      </div>
    );
  }

  if (error && !dashboard) {
    return (
      <div className="admin-dashboard">
        <div className="admin-error">
          <h2>Unable to load dashboard</h2>
          <p>{error}</p>
          <button onClick={() => fetchDashboard()}>
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (!dashboard) {
    return null;
  }

  const totalAreas = Number(dashboard.total_parking_areas) || 0;
  const totalSlots = Number(dashboard.total_slots) || 0;
  const availableSlots = Number(dashboard.available_slots) || 0;
  const totalUsers = Number(dashboard.total_users) || 0;
  const totalBookings = Number(dashboard.total_bookings) || 0;
  const activeBookings = Number(dashboard.active_bookings) || 0;

  const occupiedSlots = Math.max(0, totalSlots - availableSlots);

  const occupancyRate =
    totalSlots > 0
      ? Math.round((occupiedSlots / totalSlots) * 100)
      : 0;

  const availabilityRate =
    totalSlots > 0
      ? Math.round((availableSlots / totalSlots) * 100)
      : 0;

  const stats = [
    {
      title: "Parking Areas",
      value: totalAreas,
      icon: "📍",
      description: "Total parking locations",
      color: "purple",
    },
    {
      title: "Total Parking Slots",
      value: totalSlots,
      icon: "🅿️",
      description: "Across all parking areas",
      color: "blue",
    },
    {
      title: "Active Bookings",
      value: activeBookings,
      icon: "📅",
      description: "Currently active bookings",
      color: "orange",
    },
    {
      title: "Registered Users",
      value: totalUsers,
      icon: "👥",
      description: "Total registered accounts",
      color: "green",
    },
    {
      title: "Total Bookings",
      value: totalBookings,
      icon: "📊",
      description: "All booking records",
      color: "pink",
    },
  ];

  return (
    <div className="admin-dashboard">

      {/* Dashboard Header */}
      <div className="admin-header">
        <div>
          <p className="admin-eyebrow">SMARTPARK MANAGEMENT</p>
          <h1>Dashboard Overview</h1>
          <p className="admin-welcome">
            Monitor your parking system and manage operations.
          </p>
        </div>

        <div className="admin-header-actions">
          <span className="admin-badge">
            <span className="admin-online-dot"></span>
            Administrator
          </span>

          <button
            className="admin-refresh-btn"
            onClick={() => fetchDashboard(true)}
            disabled={refreshing}
          >
            {refreshing ? "Refreshing..." : "↻ Refresh"}
          </button>
        </div>
      </div>

      {/* Background refresh error */}
      {error && (
        <div className="admin-error">
          <p>{error}</p>
          <button onClick={() => fetchDashboard(true)}>
            Try Again
          </button>
        </div>
      )}

      {/* Statistics Cards */}
      <div className="admin-stats">
        {stats.map((stat) => (
          <div className="admin-stat-card" key={stat.title}>
            <div className="admin-stat-top">
              <div className={`admin-stat-icon ${stat.color}`}>
                {stat.icon}
              </div>
              <span className="admin-stat-label">OVERVIEW</span>
            </div>

            <h2>{stat.value.toLocaleString("en-IN")}</h2>
            <h3>{stat.title}</h3>
            <p>{stat.description}</p>
          </div>
        ))}
      </div>

      {/* Main Analytics Section */}
      <div className="admin-analytics-grid">

        {/* Parking Occupancy */}
        <div className="admin-panel occupancy-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>Parking Occupancy</h2>
              <p>Current status of all parking slots</p>
            </div>
            <span className="admin-panel-icon">🅿️</span>
          </div>

          <div className="occupancy-content">
            <div
              className="occupancy-donut"
              style={{
                background: `conic-gradient(#2563eb 0% ${occupancyRate}%, #dbeafe ${occupancyRate}% 100%)`,
              }}
            >
              <div className="occupancy-donut-inner">
                <strong>{occupancyRate}%</strong>
                <span>Occupied</span>
              </div>
            </div>

            <div className="occupancy-legend">
              <div className="legend-item">
                <span className="legend-dot occupied-dot"></span>
                <div>
                  <p>Occupied Slots</p>
                  <strong>{occupiedSlots}</strong>
                </div>
              </div>

              <div className="legend-item">
                <span className="legend-dot available-dot"></span>
                <div>
                  <p>Available Slots</p>
                  <strong>{availableSlots}</strong>
                </div>
              </div>

              <div className="legend-item">
                <span className="legend-dot total-dot"></span>
                <div>
                  <p>Total Capacity</p>
                  <strong>{totalSlots}</strong>
                </div>
              </div>
            </div>
          </div>

          <div className="occupancy-progress-section">
            <div className="progress-heading">
              <span>Slot utilization</span>
              <strong>{occupancyRate}%</strong>
            </div>

            <div className="admin-progress-track">
              <div
                className="admin-progress-fill"
                style={{ width: `${occupancyRate}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Booking Summary */}
        <div className="admin-panel booking-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>Booking Summary</h2>
              <p>Overview of recorded bookings</p>
            </div>
            <span className="admin-panel-icon">📋</span>
          </div>

          <div className="booking-summary-number">
            <strong>{totalBookings}</strong>
            <span>Total bookings recorded</span>
          </div>

          <div className="booking-metric">
            <div className="booking-metric-heading">
              <span>Active Bookings</span>
              <strong>{activeBookings}</strong>
            </div>

            <div className="admin-progress-track">
              <div
                className="booking-progress-active"
                style={{
                  width: `${
                    totalBookings > 0
                      ? Math.min(
                          (activeBookings / totalBookings) * 100,
                          100
                        )
                      : 0
                  }%`,
                }}
              ></div>
            </div>
          </div>

          <div className="booking-metric">
            <div className="booking-metric-heading">
              <span>Other Booking Records</span>
              <strong>
                {Math.max(0, totalBookings - activeBookings)}
              </strong>
            </div>

            <div className="admin-progress-track">
              <div
                className="booking-progress-other"
                style={{
                  width: `${
                    totalBookings > 0
                      ? Math.min(
                          ((totalBookings - activeBookings) /
                            totalBookings) *
                            100,
                          100
                        )
                      : 0
                  }%`,
                }}
              ></div>
            </div>
          </div>

          <div className="booking-panel-footer">
            <span>Active booking count</span>
            <strong>
              {activeBookings} / {totalBookings}
            </strong>
          </div>
        </div>
      </div>

      {/* Slot Availability */}
      <div className="admin-panel availability-panel">
        <div className="admin-panel-heading">
          <div>
            <h2>Slot Availability</h2>
            <p>Distribution of parking space across the system</p>
          </div>
          <span className="admin-panel-icon">📈</span>
        </div>

        <div className="availability-bar">
          <div
            className="availability-bar-occupied"
            style={{ width: `${occupancyRate}%` }}
            title={`Occupied: ${occupiedSlots}`}
          ></div>

          <div
            className="availability-bar-free"
            style={{ width: `${availabilityRate}%` }}
            title={`Available: ${availableSlots}`}
          ></div>
        </div>

        <div className="availability-details">
          <div>
            <span className="legend-dot occupied-dot"></span>
            <span>Occupied</span>
            <strong>{occupancyRate}%</strong>
          </div>

          <div>
            <span className="legend-dot available-dot"></span>
            <span>Available</span>
            <strong>{availabilityRate}%</strong>
          </div>
        </div>
      </div>

      {/* Quick Insights */}
      <div className="admin-panel insights-panel">
        <div className="admin-panel-heading">
          <div>
            <h2>System Insights</h2>
            <p>Quick snapshot of your parking operations</p>
          </div>
          <span className="admin-panel-icon">💡</span>
        </div>

        <div className="insights-grid">
          <div className="insight-item">
            <span className="insight-icon">🏢</span>
            <div>
              <strong>{totalAreas}</strong>
              <p>Parking locations managed</p>
            </div>
          </div>

          <div className="insight-item">
            <span className="insight-icon">🚗</span>
            <div>
              <strong>{occupancyRate}%</strong>
              <p>Current parking occupancy</p>
            </div>
          </div>

          <div className="insight-item">
            <span className="insight-icon">🟢</span>
            <div>
              <strong>{availableSlots}</strong>
              <p>Slots currently available</p>
            </div>
          </div>

          <div className="insight-item">
            <span className="insight-icon">👤</span>
            <div>
              <strong>{totalUsers}</strong>
              <p>Registered system users</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}

export default AdminDashboard;
