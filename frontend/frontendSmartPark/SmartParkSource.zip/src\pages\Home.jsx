
import { useNavigate } from "react-router-dom";
import "./Home.css";

function Home() {
  const navigate = useNavigate();

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <span className="hero-tag">SMART PARKING MADE SIMPLE</span>

          <h1>
            Your Parking Spot,
            <br />
            <span>Just a Click Away.</span>
          </h1>

          <p>
            Find available parking, reserve your spot, and enjoy
            a hassle-free parking experience with SmartPark.
          </p>

          <button
            className="hero-btn"
            onClick={() => navigate("/search")}
          >
            Find Parking <span>→</span>
          </button>

          <div className="hero-points">
            <span>✓ Easy Reservations</span>
            <span>✓ Convenient Parking</span>
          </div>
        </div>

        <div className="hero-visual">
          <div className="parking-icon">P</div>
          <div className="parking-visual-text">
            <span>YOUR SPACE.</span>
            <strong>YOUR TIME.</strong>
            <span>YOUR CONVENIENCE.</span>
          </div>
          <div className="road-line"></div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="section-heading">
          <span>WHY SMARTPARK?</span>
          <h2>Parking made easier for you</h2>
          <p>
            Spend less time searching and more time doing what matters.
          </p>
        </div>

        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">📍</div>
            <h3>Find Nearby Parking</h3>
            <p>
              Discover parking areas and check available spaces
              before you arrive.
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">📅</div>
            <h3>Reserve in Advance</h3>
            <p>
              Book your parking slot ahead of time for a smoother
              arrival.
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">💳</div>
            <h3>Transparent Pricing</h3>
            <p>
              Check parking charges and estimate your cost before
              making a reservation.
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="home-cta">
        <div>
          <h2>Ready to find your parking spot?</h2>
          <p>Your next parking space is just a few clicks away.</p>
        </div>

        <button
          className="hero-btn"
          onClick={() => navigate("/search")}
        >
          Get Started →
        </button>
      </section>
    </div>
  );
}

export default Home;
