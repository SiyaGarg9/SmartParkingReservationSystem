
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function Payment() {
  const location = useLocation();
  const navigate = useNavigate();

  const { bookingId, amount } = location.state || {};

  const [paymentMethod, setPaymentMethod] = useState("UPI");
  const [loading, setLoading] = useState(false);
  const [payment, setPayment] = useState(null);
  const [error, setError] = useState("");

  const handlePayment = async () => {
    if (!bookingId || !amount) {
      setError("Booking details are missing. Please create a booking first.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch("http://127.0.0.1:8000/payments", {
        method: "POST",
        headers: {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("user_access_token")}`,
},
        body: JSON.stringify({
          booking_id: Number(bookingId),
          amount: Number(amount),
          payment_method: paymentMethod,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Payment failed");
      }

      setPayment(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1>Parking Payment</h1>
        <p style={styles.subtitle}>Complete your simulated booking payment</p>

        {payment ? (
          <div>
            <h2 style={{ color: "green" }}>Payment Successful!</h2>
            <p><strong>Payment ID:</strong> {payment.payment_id}</p>
            <p><strong>Booking ID:</strong> {payment.booking_id}</p>
            <p><strong>Amount Paid:</strong> ₹{payment.amount}</p>
            <p><strong>Payment Method:</strong> {payment.payment_method}</p>
            <p><strong>Transaction ID:</strong> {payment.transaction_id}</p>
            <p><strong>Status:</strong> {payment.payment_status}</p>

            <button
              style={styles.button}
              onClick={() => navigate("/bookings")}
            >
              View My Bookings
            </button>
          </div>
        ) : (
          <>
            <div style={styles.details}>
              <p><strong>Booking ID:</strong> {bookingId || "Not available"}</p>
              <h2>Amount: ₹{amount ?? "Not available"}</h2>
            </div>

            <h3>Select Payment Method</h3>

            {["UPI", "CARD", "NET_BANKING", "WALLET"].map((method) => (
              <label key={method} style={styles.option}>
                <input
                  type="radio"
                  name="payment"
                  value={method}
                  checked={paymentMethod === method}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />
                {method.replace("_", " ")}
              </label>
            ))}

            <p style={styles.note}>
              Demo payment only. No real money will be transferred.
            </p>

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button
              style={styles.button}
              onClick={handlePayment}
              disabled={loading || !bookingId || amount == null}
            >
              {loading ? "Processing..." : "Pay Now"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "80vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "30px",
    background: "#f4f7fb",
  },
  card: {
    width: "100%",
    maxWidth: "450px",
    background: "white",
    padding: "30px",
    borderRadius: "12px",
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
  },
  subtitle: {
    color: "#666",
  },
  details: {
    background: "#f1f5f9",
    padding: "15px",
    borderRadius: "8px",
    margin: "20px 0",
  },
  option: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    padding: "12px",
    border: "1px solid #ddd",
    borderRadius: "7px",
    marginBottom: "10px",
    cursor: "pointer",
  },
  note: {
    fontSize: "13px",
    color: "#777",
    marginTop: "18px",
  },
  button: {
    width: "100%",
    padding: "13px",
    background: "#2563eb",
    color: "white",
    border: "none",
    borderRadius: "7px",
    cursor: "pointer",
    fontSize: "16px",
    marginTop: "15px",
  },
};

export default Payment;
