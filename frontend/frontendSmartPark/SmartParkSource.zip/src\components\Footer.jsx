import { Link } from "react-router-dom";
import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-brand">
          <h2>🚗 SmartPark</h2>
          <p>
            Smart and convenient parking reservations.
            Find your spot and park with ease.
          </p>
        </div>

        <div className="footer-links">
          <h3>Quick Links</h3>
          <a href="/">Home</a>
          <a href="/search">Find Parking</a>
          <a href="/bookings">My Bookings</a>
        </div>

        <div className="footer-contact">
          <h3>Contact</h3>
          <p>Email: support@smartpark.com</p>
          <p>Smart Parking Reservation System</p>
        </div>
      </div>

      <div className="footer-bottom">
        <p>
          © {new Date().getFullYear()} SmartPark.
          All rights reserved.
        </p>
      </div>
    </footer>
  );
}

export default Footer;