
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Search.css";

function Search() {
  const navigate = useNavigate();

  const [parkingData, setParkingData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [location, setLocation] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [vehicle, setVehicle] = useState("All");
  const [evOnly, setEvOnly] = useState(false);
  const [searched, setSearched] = useState(false);

  // Format date and time using the browser's local timezone
  function formatLocalDateTime(dateObject) {
    const pad = (number) => String(number).padStart(2, "0");

    return (
      `${dateObject.getFullYear()}-` +
      `${pad(dateObject.getMonth() + 1)}-` +
      `${pad(dateObject.getDate())}T` +
      `${pad(dateObject.getHours())}:` +
      `${pad(dateObject.getMinutes())}:` +
      `${pad(dateObject.getSeconds())}`
    );
  }

  useEffect(() => {
    let isMounted = true;

    async function loadParkingData() {
      try {
        setError("");

        // Determine the one-hour availability window
        const startDateTime =
          date && time
            ? `${date}T${time}:00`
            : formatLocalDateTime(new Date());

        const startDate = new Date(startDateTime);

        if (Number.isNaN(startDate.getTime())) {
          throw new Error("Please select a valid arrival date and time.");
        }

        const endDateTime = formatLocalDateTime(
          new Date(startDate.getTime() + 60 * 60 * 1000)
        );

        // Fetch all parking areas
        const areasResponse = await fetch(
          "http://127.0.0.1:8000/parking/areas"
        );

        if (!areasResponse.ok) {
          throw new Error("Could not fetch parking areas.");
        }

        const areasData = await areasResponse.json();

        const areas = Array.isArray(areasData)
          ? areasData
          : areasData.areas || areasData.data || [];

        // Fetch total slots and time-based availability for every area
        const formattedAreas = await Promise.all(
          areas.map(async (area) => {
            const areaId = area.id ?? area.area_id;

            // Fetch all slots to calculate the total
            const slotsResponse = await fetch(
              `http://127.0.0.1:8000/parking/areas/${areaId}/slots`
            );

            if (!slotsResponse.ok) {
              throw new Error(
                `Could not fetch slots for parking area ${areaId}.`
              );
            }

            const slotsData = await slotsResponse.json();

            const allSlots = Array.isArray(slotsData)
              ? slotsData
              : slotsData.slots || slotsData.data || [];

            // Fetch slots available during the selected one-hour window
            const searchParams = new URLSearchParams({
              area_name: area.name ?? area.area_name ?? "",
              start_time: startDateTime,
              end_time: endDateTime,
            });

            const availabilityResponse = await fetch(
              `http://127.0.0.1:8000/parking/search?${searchParams.toString()}`
            );

            if (!availabilityResponse.ok) {
              throw new Error(
                `Could not fetch live availability for ${area.name ?? areaId}.`
              );
            }

            const availabilityData = await availabilityResponse.json();

            // The /parking/search endpoint returns a flat array
            const availableSlots = Array.isArray(availabilityData)
              ? availabilityData
              : [];

            const availableEVSlots = availableSlots.filter(
              (slot) => slot.is_ev_charging === true
            );

            return {
              id: areaId,
              name:
                area.name ??
                area.area_name ??
                "Parking Area " + areaId,
              location:
                area.location ??
                area.zone ??
                area.address ??
                "Parking area",
              price: area.price ?? area.hourly_rate ?? null,
              available: availableSlots.length,
              total: allSlots.length,
              evCharging: availableEVSlots.length > 0,
              evAvailableCount: availableEVSlots.length,
              covered: area.covered ?? area.is_covered ?? null,
            };
          })
        );

        if (isMounted) {
          setParkingData(formattedAreas);
        }
      } catch (err) {
        console.error("Parking data error:", err);

        if (isMounted) {
          setError(
            err.message ||
              "Unable to load parking data. Please check the backend."
          );
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    loadParkingData();

    // Refresh availability every 30 seconds
    const refreshInterval = setInterval(() => {
      loadParkingData();
    }, 30000);

    return () => {
      isMounted = false;
      clearInterval(refreshInterval);
    };
  }, [date, time]);

  const filteredParking = parkingData.filter((parking) => {
    const searchText = location.trim().toLowerCase();

    const matchesLocation =
      parking.name.toLowerCase().includes(searchText) ||
      parking.location.toLowerCase().includes(searchText);

    const matchesEV = !evOnly || parking.evCharging;

    return matchesLocation && matchesEV;
  });

  function handleSearch(event) {
    event.preventDefault();
    setSearched(true);
  }

  return (
    <div className="search-parking-page">
      <section className="search-hero">
        <div className="search-heading">
          <span className="search-tag">SMART PARKING SOLUTIONS</span>
          <h1>Find your perfect parking spot.</h1>
          <p>
            Search nearby parking areas, compare prices,
            and choose a space that works for you.
          </p>
        </div>

        <div className="search-form-container">
          <form className="parking-search-form" onSubmit={handleSearch}>
            <div className="search-field">
              <label htmlFor="parking-location">
                Parking location
              </label>
              <input
                id="parking-location"
                type="text"
                placeholder="Enter area or parking name"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>

            <div className="search-field">
              <label htmlFor="parking-date">Arrival date</label>
              <input
                id="parking-date"
                type="date"
                min={formatLocalDateTime(new Date()).slice(0, 10)}
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>

            <div className="search-field">
              <label htmlFor="parking-time">Arrival time</label>
              <input
                id="parking-time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
              />
            </div>

            <button type="submit" className="parking-search-btn">
              Search Parking
            </button>
          </form>
        </div>
      </section>

      <section className="parking-results-section">
        <div className="results-header">
          <div>
            <span className="results-eyebrow">AVAILABLE SPACES</span>
            <h2>Explore parking areas</h2>
            <p>Compare parking availability and facilities.</p>
          </div>

          <div className="results-count">
            {loading
              ? "Loading..."
              : `${filteredParking.length} locations`}
          </div>
        </div>

        <div className="parking-filters">
          <label htmlFor="vehicle-type">Vehicle type</label>

          <select
            id="vehicle-type"
            value={vehicle}
            onChange={(e) => setVehicle(e.target.value)}
          >
            <option value="All">All vehicles</option>
            <option value="Car">Car</option>
            <option value="Bike">Bike</option>
            <option value="EV">Electric vehicle</option>
          </select>

          <label className="ev-filter">
            <input
              type="checkbox"
              checked={evOnly}
              onChange={(e) => setEvOnly(e.target.checked)}
            />
            EV charging available
          </label>
        </div>

        {searched && (
          <p className="search-feedback">
            Showing results for{" "}
            <strong>{location.trim() || "all locations"}</strong>
            {date && ` on ${date}`}
            {time && ` at ${time}`}
            {!date && !time && " for the current one-hour window"}.
          </p>
        )}

        <div className="parking-results">
          {loading && <p>Loading parking areas and slots...</p>}

          {!loading && error && (
            <div className="no-parking-results">
              <h3>Unable to load parking data</h3>
              <p>{error}</p>
              <button
                className="clear-search-btn"
                onClick={() => window.location.reload()}
              >
                Try Again
              </button>
            </div>
          )}

          {!loading &&
            !error &&
            filteredParking.map((parking) => (
              <article className="parking-card" key={parking.id}>
                <div className="parking-card-visual">
                  <div className="parking-symbol">P</div>
                  <span className="parking-status">
                    {parking.available} spaces available
                  </span>
                </div>

                <div className="parking-card-content">
                  <div className="parking-card-heading">
                    <div>
                      <h3>{parking.name}</h3>
                      <p className="parking-location">
                        <span>⌖</span> {parking.location}
                      </p>
                    </div>

                    <div className="parking-price">
                      <strong>
                        {parking.price !== null
                          ? `₹${parking.price}`
                          : "Price N/A"}
                      </strong>
                      {parking.price !== null && (
                        <span>per hour</span>
                      )}
                    </div>
                  </div>

                  <div className="parking-facilities">
                    <span>🚘 Parking</span>

                    <span>
                      {parking.covered === null
                        ? "Covering details unavailable"
                        : parking.covered
                          ? "✓ Covered"
                          : "Open parking"}
                    </span>

                    {parking.evCharging && (
                      <span>
                        ⚡ {parking.evAvailableCount} EV slots available
                      </span>
                    )}
                  </div>

                  <div className="parking-card-bottom">
                    <span>
                      {parking.available} of {parking.total} slots free
                    </span>

                    <button
                      className="book-parking-btn"
                      onClick={() =>
                        navigate("/booking", {
                          state: {
                            parkingId: parking.id,
                            parkingName: parking.name,
                            location: parking.location,
                            ratePerHour: parking.price,
                            date,
                            time,
                            vehicle,
                          },
                        })
                      }
                    >
                      Book Parking →
                    </button>
                  </div>
                </div>
              </article>
            ))}

          {!loading &&
            !error &&
            filteredParking.length === 0 && (
              <div className="no-parking-results">
                <span>🔎</span>
                <h3>No parking areas found</h3>
                <p>Try another location or change your filters.</p>

                <button
                  className="clear-search-btn"
                  onClick={() => {
                    setLocation("");
                    setEvOnly(false);
                    setVehicle("All");
                    setDate("");
                    setTime("");
                    setSearched(false);
                  }}
                >
                  Clear filters
                </button>
              </div>
            )}
        </div>

        <p className="sample-data-note">
          Slot availability is checked against bookings for the selected
          one-hour window. Pricing is shown only when provided by the
          parking area API.
        </p>
      </section>
    </div>
  );
}

export default Search;
