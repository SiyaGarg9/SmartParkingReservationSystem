import { useState } from "react";
import "./AdminReports.css";

const monthlyData = [
  { month: "May", bookings: 120, revenue: 12000 },
  { month: "Jun", bookings: 165, revenue: 16500 },
  { month: "Jul", bookings: 145, revenue: 14500 },
  { month: "Aug", bookings: 210, revenue: 21000 },
  { month: "Sep", bookings: 185, revenue: 18500 },
  { month: "Oct", bookings: 240, revenue: 24000 },
];

const parkingData = [
  { name: "City Centre Parking", bookings: 145, occupancy: 78 },
  { name: "Bus Stand Parking", bookings: 110, occupancy: 65 },
  { name: "Market Square Parking", bookings: 95, occupancy: 82 },
];

function AdminReports() {
  const [period, setPeriod] = useState("6");

  const visibleData = monthlyData.slice(-Number(period));

  const totalBookings = visibleData.reduce(
    (sum, item) => sum + item.bookings,
    0
  );

  const totalRevenue = visibleData.reduce(
    (sum, item) => sum + item.revenue,
    0
  );

  const maxRevenue = Math.max(...visibleData.map((item) => item.revenue), 1);
  const maxBookings = Math.max(...visibleData.map((item) => item.bookings), 1);

  const averageOccupancy = Math.round(
    parkingData.reduce((sum, area) => sum + area.occupancy, 0) /
      parkingData.length
  );

  return (
    <div className="admin-reports">
      <div className="reports-header">
        <div>
          <h1>Reports & Analytics</h1>
          <p>Monitor SmartPark bookings, revenue, and parking occupancy.</p>
        </div>

        <select
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          aria-label="Select report period"
        >
          <option value="3">Last 3 Months</option>
          <option value="6">Last 6 Months</option>
        </select>
      </div>

      <div className="reports-summary">
        <div className="report-stat-card">
          <span>Total Bookings</span>
          <strong>{totalBookings.toLocaleString("en-IN")}</strong>
          <small>For selected period</small>
        </div>

        <div className="report-stat-card">
          <span>Total Revenue</span>
          <strong>₹{totalRevenue.toLocaleString("en-IN")}</strong>
          <small>For selected period</small>
        </div>

        <div className="report-stat-card">
          <span>Average Occupancy</span>
          <strong>{averageOccupancy}%</strong>
          <small>Across sample parking areas</small>
        </div>

        <div className="report-stat-card">
          <span>Parking Areas</span>
          <strong>{parkingData.length}</strong>
          <small>Included in this report</small>
        </div>
      </div>

      <div className="reports-chart-grid">
        <section className="report-panel">
          <h2>Monthly Bookings</h2>
          <p className="report-subtitle">Number of bookings per month</p>

          <div className="report-bar-chart">
            {visibleData.map((item) => (
              <div className="report-bar-item" key={item.month}>
                <span className="report-bar-value">{item.bookings}</span>
                <div className="report-bar-track">
                  <div
                    className="report-bar-fill bookings-fill"
                    style={{
                      height: `${(item.bookings / maxBookings) * 100}%`,
                    }}
                  />
                </div>
                <span className="report-bar-label">{item.month}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="report-panel">
          <h2>Monthly Revenue</h2>
          <p className="report-subtitle">Revenue in rupees</p>

          <div className="report-bar-chart">
            {visibleData.map((item) => (
              <div className="report-bar-item" key={item.month}>
                <span className="report-bar-value">
                  ₹{(item.revenue / 1000).toFixed(1)}k
                </span>
                <div className="report-bar-track">
                  <div
                    className="report-bar-fill revenue-fill"
                    style={{
                      height: `${(item.revenue / maxRevenue) * 100}%`,
                    }}
                  />
                </div>
                <span className="report-bar-label">{item.month}</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="report-panel parking-performance">
        <h2>Parking Area Performance</h2>
        <p className="report-subtitle">
          Booking volume and estimated occupancy by location
        </p>

        <div className="performance-table-wrapper">
          <table className="performance-table">
            <thead>
              <tr>
                <th>Parking Area</th>
                <th>Total Bookings</th>
                <th>Occupancy</th>
              </tr>
            </thead>

            <tbody>
              {parkingData.map((area) => (
                <tr key={area.name}>
                  <td>{area.name}</td>
                  <td>{area.bookings}</td>
                  <td>
                    <div className="occupancy-cell">
                      <div className="occupancy-track">
                        <div
                          className="occupancy-fill"
                          style={{ width: `${area.occupancy}%` }}
                        />
                      </div>
                      <span>{area.occupancy}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <p className="reports-note">
        These reports use sample data. Revenue and occupancy figures are
        illustrative and are not connected to live bookings.
      </p>
    </div>
  );
}

export default AdminReports;