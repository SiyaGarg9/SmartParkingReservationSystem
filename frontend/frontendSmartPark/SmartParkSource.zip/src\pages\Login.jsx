
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";

const API_URL = "http://127.0.0.1:8000";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");

    if (!email.trim() || !password) {
      setError("Please enter your email and password.");
      return;
    }

    try {
      setLoading(true);

      const response = await fetch(`${API_URL}/users/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email.trim(),
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "Login failed. Please check your credentials."
        );
      }

      if (!data.access_token || !data.role) {
        throw new Error("Login information was not returned correctly.");
      }

      const tokenParts = data.access_token.split(".");

      if (tokenParts.length !== 3) {
        throw new Error("Invalid login token.");
      }

      const base64Payload = tokenParts[1]
        .replace(/-/g, "+")
        .replace(/_/g, "/");

      const payload = JSON.parse(
        window.atob(
          base64Payload.padEnd(
            Math.ceil(base64Payload.length / 4) * 4,
            "="
          )
        )
      );

      const userId = payload.sub;

      if (!userId) {
        throw new Error("User ID not found in login token.");
      }

      const role = data.role.toUpperCase();
      const token = data.access_token;
      const tokenType = data.token_type || "bearer";

      // One shared login session.
      localStorage.setItem("access_token", token);

      // Keep compatibility with existing Admin and User pages.
      // All these keys contain the SAME active login token.
      localStorage.setItem("admin_access_token", token);
      localStorage.setItem("user_access_token", token);

      localStorage.setItem("user_id", String(userId));
      localStorage.setItem("admin_user_id", String(userId));

      localStorage.setItem("user_email", email.trim());
      localStorage.setItem("admin_user_email", email.trim());

      localStorage.setItem("user_role", role);
      localStorage.setItem("role", role);

      localStorage.setItem("user_token_type", tokenType);
      localStorage.setItem("admin_token_type", tokenType);

      if (role === "ADMIN") {
        navigate("/admin");
      } else {
        navigate("/");
      }
    } catch (err) {
      if (err instanceof TypeError) {
        setError(
          "Cannot connect to the backend. Make sure FastAPI is running."
        );
      } else {
        setError(err.message || "Something went wrong. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <section className="login-visual">
        <Link to="/" className="login-brand">
          <span>🚗</span> SmartPark
        </Link>

        <div className="login-visual-content">
          <div className="login-parking-symbol">P</div>

          <h1>Parking made simple.</h1>

          <p>
            Your parking spot is just a few clicks away.
            Sign in to manage your reservations and make every
            journey easier.
          </p>

          <div className="login-benefits">
            <span>✓ Easy parking reservations</span>
            <span>✓ Manage your bookings</span>
            <span>✓ Convenient parking solutions</span>
          </div>
        </div>

        <p className="login-visual-footer">
          Smart parking. Smoother journeys.
        </p>
      </section>

      <section className="login-form-section">
        <div className="login-form-container">
          <div className="login-mobile-brand">
            🚗 SmartPark
          </div>

          <span className="login-eyebrow">WELCOME BACK</span>
          <h2>Sign in to your account</h2>

          <p className="login-description">
            Enter your details to access your SmartPark account.
          </p>

          <form className="login-form" onSubmit={handleSubmit}>
            <div className="login-field">
              <label htmlFor="login-email">Email address</label>

              <input
                id="login-email"
                type="email"
                placeholder="you@example.com"
                autoComplete="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                required
              />
            </div>

            <div className="login-field">
              <div className="password-label-row">
                <label htmlFor="login-password">Password</label>
              </div>

              <div className="password-input-wrapper">
                <input
                  id="login-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  required
                />

                <button
                  type="button"
                  className="toggle-password"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={
                    showPassword ? "Hide password" : "Show password"
                  }
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
            </div>

            {error && (
              <p className="login-error" role="alert">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="login-submit-btn"
              disabled={loading}
            >
              {loading ? "Signing in..." : "Sign In"}
              {!loading && <span> →</span>}
            </button>
          </form>

          <p className="login-register-text">
            Don't have an account?{" "}
            <Link to="/register">Create an account</Link>
          </p>

          <Link to="/" className="login-home-link">
            ← Back to Home
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Login;
