
import { useEffect, useRef, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Html5QrcodeScanner } from "html5-qrcode";
import "./ManageBookings.css";

const API_URL = "http://127.0.0.1:8000";

function getDisplayStatus(status) {
  const statusMap = {
    BOOKED: "Confirmed",
    IN_PROGRESS: "In Progress",
    COMPLETED: "Completed",
    CANCELLED: "Cancelled",
  };

  return statusMap[status] || status;
}

function formatDate(dateValue) {
  if (!dateValue) return "Not available";
  return new Date(dateValue).toLocaleDateString("en-CA");
}

function formatTime(start, end) {
  if (!start || !end) return "Not available";

  return `${new Date(start).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  })} - ${new Date(end).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

function ManageBookings() {
  const [bookings, setBookings] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [selectedBooking, setSelectedBooking] = useState(null);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  // EXIT QR STATES
  const [exitQr, setExitQr] = useState(null);
  const [generatingExitQr, setGeneratingExitQr] = useState(false);

  // QR SCANNER STATES
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scanMessage, setScanMessage] = useState("");
  const [scanning, setScanning] = useState(false);

  const scannerRef = useRef(null);
  const scanHandledRef = useRef(false);

  // FETCH REAL BOOKINGS
  async function fetchBookings(showLoading = true) {
    try {
      if (showLoading) {
        setLoading(true);
      } else {
        setRefreshing(true);
      }

      setError("");

      const token = localStorage.getItem("access_token");

      if (!token) {
        throw new Error("Please log in as administrator.");
      }

      const headers = {
        Authorization: `Bearer ${token}`,
      };

      const [bookingResponse, areaResponse, slotResponse] =
        await Promise.all([
          fetch(`${API_URL}/admin/bookings`, { headers }),
          fetch(`${API_URL}/admin/areas`, { headers }),
          fetch(`${API_URL}/admin/slots`, { headers }),
        ]);

      const bookingData = await bookingResponse.json();
      const areaData = await areaResponse.json();
      const slotData = await slotResponse.json();

      if (!bookingResponse.ok) {
        throw new Error(bookingData.detail || "Unable to fetch bookings.");
      }

      if (!areaResponse.ok) {
        throw new Error(areaData.detail || "Unable to fetch parking areas.");
      }

      if (!slotResponse.ok) {
        throw new Error(slotData.detail || "Unable to fetch parking slots.");
      }

      const areas = Array.isArray(areaData) ? areaData : [];
      const slots = Array.isArray(slotData) ? slotData : [];
      const bookingList = Array.isArray(bookingData) ? bookingData : [];

      const areaMap = {};
      const slotMap = {};

      areas.forEach((area) => {
        areaMap[area.area_id] = area;
      });

      slots.forEach((slot) => {
        slotMap[slot.slot_id] = slot;
      });

      const bookingsWithDetails = await Promise.all(
        bookingList.map(async (booking) => {
          const slot = slotMap[booking.slot_id];
          const area = slot ? areaMap[slot.area_id] : null;

          let payment = null;

          try {
            const paymentResponse = await fetch(
              `${API_URL}/payments/booking/${booking.booking_id}`
            );

            if (paymentResponse.ok) {
              payment = await paymentResponse.json();
            }
          } catch (err) {
            console.error("Payment fetch error:", err);
          }

          return {
            id: booking.booking_id,
            userId: booking.user_id,
            user: booking.user_name || "Unknown User",
            email: booking.email || "Not available",
            parkingArea: area?.name || "Not available",
            slot: slot?.slot_no || booking.slot_no || booking.slot_id,
            date: formatDate(booking.start_time),
            time: formatTime(booking.start_time, booking.end_time),
            amount: payment?.amount ?? "—",
            status: getDisplayStatus(booking.status),
            rawStatus: booking.status,
            paymentStatus: payment?.payment_status || "Not available",
          };
        })
      );

      setBookings(bookingsWithDetails);

      setSelectedBooking((previous) => {
        if (!previous) return null;

        return (
          bookingsWithDetails.find(
            (booking) => booking.id === previous.id
          ) || null
        );
      });
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    fetchBookings();
  }, []);

  // GENERATE EXIT QR
  async function generateExitQr(booking) {
    try {
      setGeneratingExitQr(true);
      setError("");

      const response = await fetch(
        `${API_URL}/qr/generate-exit/${booking.id}`,
        {
          method: "POST",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Unable to generate Exit QR.");
      }

      const token =
        data.exit_qr_token ||
        data.exit_token ||
        data.qr_token;

      if (!token) {
        throw new Error("Exit QR token was not returned by the server.");
      }

      setExitQr({
        bookingId: booking.id,
        token: token,
      });
    } catch (err) {
      alert(err.message);
    } finally {
      setGeneratingExitQr(false);
    }
  }

  // SCAN EXIT QR
  async function handleExitScan(decodedText) {
    if (scanHandledRef.current) return;

    scanHandledRef.current = true;
    setScanning(true);
    setScanMessage("Processing exit...");

    try {
      if (scannerRef.current) {
        await scannerRef.current.clear();
        scannerRef.current = null;
      }

      const response = await fetch(
        `${API_URL}/qr/exit/${encodeURIComponent(decodedText)}`,
        {
          method: "POST",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Exit verification failed.");
      }

      setScanMessage(
        data.message || "Exit approved! Booking completed successfully."
      );

      await fetchBookings(false);
    } catch (err) {
      setScanMessage(err.message);
    } finally {
      setScanning(false);
      setScannerOpen(false);
      scanHandledRef.current = false;
    }
  }

  // START AND STOP CAMERA SCANNER
  useEffect(() => {
    if (!scannerOpen) return;

    scanHandledRef.current = false;

    const scanner = new Html5QrcodeScanner(
      "exit-qr-reader",
      {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        rememberLastUsedCamera: true,
      },
      false
    );

    scannerRef.current = scanner;

    scanner.render(
      (decodedText) => {
        handleExitScan(decodedText);
      },
      () => {}
    );

    return () => {
      if (scannerRef.current) {
        scannerRef.current
          .clear()
          .catch((err) => console.log("Scanner cleanup:", err));

        scannerRef.current = null;
      }
    };
  }, [scannerOpen]);

  // SEARCH AND FILTER
  const filteredBookings = bookings.filter((booking) => {
    const query = search.toLowerCase();

    const matchesSearch =
      String(booking.id).toLowerCase().includes(query) ||
      booking.user.toLowerCase().includes(query) ||
      booking.email.toLowerCase().includes(query) ||
      booking.parkingArea.toLowerCase().includes(query);

    const matchesStatus =
      statusFilter === "All" || booking.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // SUMMARY COUNTS
  const confirmedCount = bookings.filter(
    (booking) => booking.rawStatus === "BOOKED"
  ).length;

  const pendingCount = bookings.filter(
    (booking) => booking.rawStatus === "PENDING"
  ).length;

  const completedCount = bookings.filter(
    (booking) => booking.rawStatus === "COMPLETED"
  ).length;

  // CANCEL BOOKING
  async function cancelBooking(booking) {
    if (
      booking.rawStatus === "COMPLETED" ||
      booking.rawStatus === "CANCELLED"
    ) {
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to cancel booking #${booking.id}?`
    );

    if (!confirmed) return;

    try {
      const token = localStorage.getItem("access_token");

      const response = await fetch(
        `${API_URL}/admin/bookings/${booking.id}/cancel`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Unable to cancel booking.");
      }

      alert("Booking cancelled successfully!");
      await fetchBookings(false);
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div className="manage-bookings">
      <div className="bookings-header">
        <div>
          <h1>Manage Bookings</h1>
          <p>View and manage customer parking reservations.</p>
        </div>

        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          <button
            onClick={() => {
              setScanMessage("");
              setScannerOpen(true);
            }}
            disabled={scanning}
          >
            Scan Exit QR
          </button>

          <button
            onClick={() => fetchBookings(false)}
            disabled={refreshing}
          >
            {refreshing ? "Refreshing..." : "↻ Refresh"}
          </button>
        </div>
      </div>

      {error && (
        <p style={{ color: "#b42318", margin: "15px 0" }}>
          {error}
        </p>
      )}

      {loading ? (
        <p>Loading bookings...</p>
      ) : (
        <>
          <div className="booking-summary">
            <div className="booking-summary-card">
              <span>Total Bookings</span>
              <strong>{bookings.length}</strong>
            </div>

            <div className="booking-summary-card">
              <span>Confirmed</span>
              <strong>{confirmedCount}</strong>
            </div>

            <div className="booking-summary-card">
              <span>Pending</span>
              <strong>{pendingCount}</strong>
            </div>

            <div className="booking-summary-card">
              <span>Completed</span>
              <strong>{completedCount}</strong>
            </div>
          </div>

          <div className="booking-controls">
            <input
              type="text"
              placeholder="Search by booking ID, user, or parking area..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search bookings"
            />

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter bookings by status"
            >
              <option value="All">All</option>
              <option value="Confirmed">Confirmed</option>
              <option value="In Progress">In Progress</option>
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <div className="bookings-table-wrapper">
            <table className="bookings-table">
              <thead>
                <tr>
                  <th>Booking ID</th>
                  <th>Customer</th>
                  <th>Parking Area / Slot</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>

              <tbody>
                {filteredBookings.map((booking) => (
                  <tr key={booking.id}>
                    <td>
                      <strong>{booking.id}</strong>
                    </td>

                    <td>
                      <div className="booking-customer">
                        <strong>{booking.user}</strong>
                        <span>{booking.email}</span>
                      </div>
                    </td>

                    <td>
                      <div className="booking-parking">
                        <strong>{booking.parkingArea}</strong>
                        <span>Slot: {booking.slot}</span>
                      </div>
                    </td>

                    <td>{booking.date}</td>

                    <td>
                      {booking.amount === "—"
                        ? "—"
                        : `₹${booking.amount}`}
                    </td>

                    <td>
                      <span
                        className={`admin-booking-status ${
                          booking.status.toLowerCase().replace(" ", "-")
                        }`}
                      >
                        {booking.status}
                      </span>
                    </td>

                    <td>
                      <div className="booking-actions">
                        <button
                          onClick={() => setSelectedBooking(booking)}
                        >
                          View
                        </button>

                        {booking.rawStatus === "IN_PROGRESS" && (
                          <button
                            onClick={() => generateExitQr(booking)}
                            disabled={generatingExitQr}
                          >
                            Generate Exit QR
                          </button>
                        )}

                        {booking.rawStatus !== "COMPLETED" &&
                          booking.rawStatus !== "CANCELLED" && (
                            <button
                              className="booking-cancel-btn"
                              onClick={() => cancelBooking(booking)}
                            >
                              Cancel
                            </button>
                          )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredBookings.length === 0 && (
              <p className="bookings-empty">No bookings found.</p>
            )}
          </div>
        </>
      )}

      {/* BOOKING DETAILS MODAL */}
      {selectedBooking && (
        <div
          className="booking-modal-overlay"
          onClick={() => setSelectedBooking(null)}
        >
          <div
            className="booking-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="booking-modal-title"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="booking-modal-header">
              <h2 id="booking-modal-title">Booking Details</h2>

              <button
                className="booking-modal-close"
                onClick={() => setSelectedBooking(null)}
                aria-label="Close booking details"
              >
                ×
              </button>
            </div>

            <p><strong>Booking ID:</strong> {selectedBooking.id}</p>
            <p><strong>User ID:</strong> {selectedBooking.userId}</p>
            <p><strong>Customer:</strong> {selectedBooking.user}</p>
            <p><strong>Email:</strong> {selectedBooking.email}</p>
            <p><strong>Parking Area:</strong> {selectedBooking.parkingArea}</p>
            <p><strong>Slot:</strong> {selectedBooking.slot}</p>
            <p><strong>Date:</strong> {selectedBooking.date}</p>
            <p><strong>Time:</strong> {selectedBooking.time}</p>
            <p><strong>Amount:</strong> ₹{selectedBooking.amount}</p>
            <p><strong>Payment Status:</strong> {selectedBooking.paymentStatus}</p>
            <p><strong>Status:</strong> {selectedBooking.status}</p>

            <button
              className="booking-modal-done"
              onClick={() => setSelectedBooking(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* GENERATED EXIT QR MODAL */}
      {exitQr && (
        <div
          className="booking-modal-overlay"
          onClick={() => setExitQr(null)}
        >
          <div
            className="booking-modal"
            role="dialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
            style={{ textAlign: "center" }}
          >
            <div className="booking-modal-header">
              <h2>Exit QR Code</h2>

              <button
                className="booking-modal-close"
                onClick={() => setExitQr(null)}
              >
                ×
              </button>
            </div>

            <p>Booking #{exitQr.bookingId}</p>

            <div style={{ margin: "25px auto" }}>
              <QRCodeSVG
                value={exitQr.token}
                size={230}
                level="H"
              />
            </div>

            <p>Show this QR code at the parking exit.</p>

            <button
              className="booking-modal-done"
              onClick={() => setExitQr(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* EXIT QR SCANNER MODAL */}
      {scannerOpen && (
        <div
          className="booking-modal-overlay"
          onClick={() => {
            if (!scanning) setScannerOpen(false);
          }}
        >
          <div
            className="booking-modal"
            role="dialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="booking-modal-header">
              <h2>Scan Exit QR</h2>

              <button
                className="booking-modal-close"
                onClick={() => {
                  if (!scanning) setScannerOpen(false);
                }}
                disabled={scanning}
              >
                ×
              </button>
            </div>

            <p>Point the camera at the customer's Exit QR code.</p>

            <div
              id="exit-qr-reader"
              style={{ width: "100%", marginTop: "15px" }}
            />

            {scanning && <p>Processing exit...</p>}

            <button
              className="booking-modal-done"
              onClick={() => setScannerOpen(false)}
              disabled={scanning}
            >
              Close Scanner
            </button>
          </div>
        </div>
      )}

      {scanMessage && !scannerOpen && (
        <div
          className="booking-modal-overlay"
          onClick={() => setScanMessage("")}
        >
          <div
            className="booking-modal"
            role="dialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >
            <h2>Exit Scan Result</h2>
            <p>{scanMessage}</p>

            <button
              className="booking-modal-done"
              onClick={() => setScanMessage("")}
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ManageBookings;
