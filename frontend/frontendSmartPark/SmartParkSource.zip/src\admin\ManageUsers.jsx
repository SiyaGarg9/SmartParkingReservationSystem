import { useState } from "react";
import "./ManageUsers.css";

const initialUsers = [
  {
    id: 1,
    name: "Rahul Sharma",
    email: "rahul@example.com",
    phone: "9876543210",
    joined: "2026-08-12",
    bookings: 8,
    status: "Active",
  },
  {
    id: 2,
    name: "Priya Verma",
    email: "priya@example.com",
    phone: "9876543211",
    joined: "2026-08-20",
    bookings: 5,
    status: "Active",
  },
  {
    id: 3,
    name: "Arjun Singh",
    email: "arjun@example.com",
    phone: "9876543212",
    joined: "2026-09-03",
    bookings: 12,
    status: "Inactive",
  },
  {
    id: 4,
    name: "Simran Kaur",
    email: "simran@example.com",
    phone: "9876543213",
    joined: "2026-09-18",
    bookings: 3,
    status: "Active",
  },
];

function ManageUsers() {
  const [users, setUsers] = useState(initialUsers);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [selectedUser, setSelectedUser] = useState(null);

  const filteredUsers = users.filter((user) => {
    const query = search.trim().toLowerCase();

    const matchesSearch =
      user.name.toLowerCase().includes(query) ||
      user.email.toLowerCase().includes(query) ||
      user.phone.includes(query);

    const matchesStatus =
      statusFilter === "All" || user.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const toggleStatus = (id) => {
    setUsers((currentUsers) =>
      currentUsers.map((user) =>
        user.id === id
          ? {
              ...user,
              status: user.status === "Active" ? "Inactive" : "Active",
            }
          : user
      )
    );

    setSelectedUser((currentUser) =>
      currentUser?.id === id
        ? {
            ...currentUser,
            status: currentUser.status === "Active" ? "Inactive" : "Active",
          }
        : currentUser
    );
  };

  const activeCount = users.filter(
    (user) => user.status === "Active"
  ).length;

  const inactiveCount = users.filter(
    (user) => user.status === "Inactive"
  ).length;

  const totalBookings = users.reduce(
    (total, user) => total + user.bookings,
    0
  );

  return (
    <div className="manage-users">
      <div className="users-header">
        <div>
          <h1>Manage Users</h1>
          <p>View registered customers and manage their accounts.</p>
        </div>
      </div>

      <div className="users-summary">
        <div className="users-summary-card">
          <span>Total Users</span>
          <strong>{users.length}</strong>
        </div>

        <div className="users-summary-card">
          <span>Active Users</span>
          <strong>{activeCount}</strong>
        </div>

        <div className="users-summary-card">
          <span>Inactive Users</span>
          <strong>{inactiveCount}</strong>
        </div>

        <div className="users-summary-card">
          <span>Total Bookings</span>
          <strong>{totalBookings}</strong>
        </div>
      </div>

      <div className="users-controls">
        <input
          type="text"
          placeholder="Search by name, email, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search users"
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          aria-label="Filter users by status"
        >
          <option>All</option>
          <option>Active</option>
          <option>Inactive</option>
        </select>
      </div>

      <div className="users-table-wrapper">
        <table className="users-table">
          <thead>
            <tr>
              <th>User</th>
              <th>Phone</th>
              <th>Joined Date</th>
              <th>Bookings</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredUsers.map((user) => (
              <tr key={user.id}>
                <td>
                  <div className="user-info">
                    <div className="user-avatar">
                      {user.name.charAt(0).toUpperCase()}
                    </div>

                    <div>
                      <strong>{user.name}</strong>
                      <span>{user.email}</span>
                    </div>
                  </div>
                </td>

                <td>{user.phone}</td>
                <td>{user.joined}</td>
                <td>{user.bookings}</td>

                <td>
                  <span
                    className={`user-status ${user.status.toLowerCase()}`}
                  >
                    {user.status}
                  </span>
                </td>

                <td>
                  <div className="user-actions">
                    <button onClick={() => setSelectedUser(user)}>
                      View
                    </button>

                    <button
                      className={
                        user.status === "Active"
                          ? "deactivate-user-btn"
                          : "activate-user-btn"
                      }
                      onClick={() => toggleStatus(user.id)}
                    >
                      {user.status === "Active" ? "Deactivate" : "Activate"}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredUsers.length === 0 && (
          <p className="users-empty">No users found.</p>
        )}
      </div>

      {selectedUser && (
        <div
          className="user-modal-overlay"
          onClick={() => setSelectedUser(null)}
        >
          <div
            className="user-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="user-modal-title"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="user-modal-header">
              <h2 id="user-modal-title">User Details</h2>

              <button
                className="user-modal-close"
                onClick={() => setSelectedUser(null)}
                aria-label="Close user details"
              >
                ×
              </button>
            </div>

            <p><strong>Name:</strong> {selectedUser.name}</p>
            <p><strong>Email:</strong> {selectedUser.email}</p>
            <p><strong>Phone:</strong> {selectedUser.phone}</p>
            <p><strong>Joined:</strong> {selectedUser.joined}</p>
            <p><strong>Total Bookings:</strong> {selectedUser.bookings}</p>
            <p><strong>Account Status:</strong> {selectedUser.status}</p>

            <button
              className="user-modal-done"
              onClick={() => setSelectedUser(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ManageUsers;