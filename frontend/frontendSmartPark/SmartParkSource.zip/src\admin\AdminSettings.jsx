import { useState } from "react";
import "./AdminSettings.css";

const defaultSettings = {
  systemName: "SmartPark",
  supportEmail: "support@smartpark.com",
  supportPhone: "",
  hourlyRate: "30",
  advanceBookingDays: "30",
  cancellationHours: "2",
  emailNotifications: true,
  bookingNotifications: true,
  maintenanceMode: false,
};

function AdminSettings() {
  const [settings, setSettings] = useState(defaultSettings);
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setSettings((current) => ({
      ...current,
      [name]: type === "checkbox" ? checked : value,
    }));

    setMessage("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const hourlyRate = Number(settings.hourlyRate);
    const advanceBookingDays = Number(settings.advanceBookingDays);
    const cancellationHours = Number(settings.cancellationHours);

    if (
      !settings.systemName.trim() ||
      !settings.supportEmail.trim() ||
      !Number.isFinite(hourlyRate) ||
      hourlyRate < 0 ||
      !Number.isInteger(advanceBookingDays) ||
      advanceBookingDays < 1 ||
      !Number.isInteger(cancellationHours) ||
      cancellationHours < 0
    ) {
      setMessage("Please enter valid settings before saving.");
      return;
    }

    setMessage("Settings saved for this session.");
  };

  const handleReset = () => {
    setSettings(defaultSettings);
    setMessage("Settings restored to their default values.");
  };

  return (
    <div className="admin-settings">
      <div className="settings-header">
        <h1>Admin Settings</h1>
        <p>Configure SmartPark system preferences and booking rules.</p>
      </div>

      <form onSubmit={handleSubmit}>
        <section className="settings-section">
          <h2>General Settings</h2>
          <p className="settings-description">
            Manage the basic information displayed for your parking platform.
          </p>

          <div className="settings-form-grid">
            <label>
              System Name
              <input
                name="systemName"
                value={settings.systemName}
                onChange={handleChange}
                required
              />
            </label>

            <label>
              Support Email
              <input
                name="supportEmail"
                type="email"
                value={settings.supportEmail}
                onChange={handleChange}
                required
              />
            </label>

            <label>
              Support Phone
              <input
                name="supportPhone"
                type="tel"
                value={settings.supportPhone}
                onChange={handleChange}
                placeholder="Enter support phone"
              />
            </label>
          </div>
        </section>

        <section className="settings-section">
          <h2>Booking & Pricing</h2>
          <p className="settings-description">
            Set the default booking rules and base parking rate.
          </p>

          <div className="settings-form-grid">
            <label>
              Default Hourly Rate (₹)
              <input
                name="hourlyRate"
                type="number"
                min="0"
                step="0.01"
                value={settings.hourlyRate}
                onChange={handleChange}
                required
              />
            </label>

            <label>
              Advance Booking Limit (days)
              <input
                name="advanceBookingDays"
                type="number"
                min="1"
                step="1"
                value={settings.advanceBookingDays}
                onChange={handleChange}
                required
              />
            </label>

            <label>
              Cancellation Cut-off (hours)
              <input
                name="cancellationHours"
                type="number"
                min="0"
                step="1"
                value={settings.cancellationHours}
                onChange={handleChange}
                required
              />
            </label>
          </div>
        </section>

        <section className="settings-section">
          <h2>Notifications</h2>
          <p className="settings-description">
            Choose which notifications the system should enable.
          </p>

          <label className="settings-toggle">
            <span>
              <strong>Email Notifications</strong>
              <small>Enable email-related notifications.</small>
            </span>
            <input
              name="emailNotifications"
              type="checkbox"
              checked={settings.emailNotifications}
              onChange={handleChange}
            />
          </label>

          <label className="settings-toggle">
            <span>
              <strong>Booking Notifications</strong>
              <small>Enable notifications about new bookings.</small>
            </span>
            <input
              name="bookingNotifications"
              type="checkbox"
              checked={settings.bookingNotifications}
              onChange={handleChange}
            />
          </label>
        </section>

        <section className="settings-section">
          <h2>System Status</h2>
          <label className="settings-toggle">
            <span>
              <strong>Maintenance Mode</strong>
              <small>
                Setting this switch only changes the value in this page;
                it does not disable the live website.
              </small>
            </span>
            <input
              name="maintenanceMode"
              type="checkbox"
              checked={settings.maintenanceMode}
              onChange={handleChange}
            />
          </label>
        </section>

        {message && (
          <p className="settings-message" role="status">
            {message}
          </p>
        )}

        <div className="settings-actions">
          <button type="submit" className="settings-save-btn">
            Save Settings
          </button>

          <button
            type="button"
            className="settings-reset-btn"
            onClick={handleReset}
          >
            Reset Defaults
          </button>
        </div>
      </form>
    </div>
  );
}

export default AdminSettings;