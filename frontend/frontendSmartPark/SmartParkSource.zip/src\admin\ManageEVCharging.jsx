import { useState } from "react";
import "./ManageEVCharging.css";

const initialStations = [
  {
    id: 1,
    name: "City Centre Charger 1",
    parkingArea: "City Centre Parking",
    chargerType: "Fast Charging",
    power: 50,
    status: "Available",
    price: 18,
  },
  {
    id: 2,
    name: "City Centre Charger 2",
    parkingArea: "City Centre Parking",
    chargerType: "Standard Charging",
    power: 22,
    status: "In Use",
    price: 12,
  },
  {
    id: 3,
    name: "Bus Stand Charger 1",
    parkingArea: "Bus Stand Parking",
    chargerType: "Fast Charging",
    power: 60,
    status: "Available",
    price: 20,
  },
  {
    id: 4,
    name: "Market Charger 1",
    parkingArea: "Market Square Parking",
    chargerType: "Standard Charging",
    power: 22,
    status: "Maintenance",
    price: 12,
  },
];

const emptyForm = {
  name: "",
  parkingArea: "City Centre Parking",
  chargerType: "Standard Charging",
  power: "",
  status: "Available",
  price: "",
};

function ManageEVCharging() {
  const [stations, setStations] = useState(initialStations);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [formData, setFormData] = useState(emptyForm);

  const filteredStations = stations.filter((station) => {
    const query = search.toLowerCase();

    const matchesSearch =
      station.name.toLowerCase().includes(query) ||
      station.parkingArea.toLowerCase().includes(query);

    const matchesStatus =
      statusFilter === "All" || station.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const resetForm = () => {
    setFormData(emptyForm);
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const power = Number(formData.power);
    const price = Number(formData.price);

    if (
      !formData.name.trim() ||
      !Number.isFinite(power) ||
      power <= 0 ||
      !Number.isFinite(price) ||
      price < 0
    ) {
      alert("Enter a valid station name, power, and price.");
      return;
    }

    const stationData = {
      ...formData,
      name: formData.name.trim(),
      power,
      price,
    };

    if (editingId !== null) {
      setStations((current) =>
        current.map((station) =>
          station.id === editingId ? { ...station, ...stationData } : station
        )
      );
    } else {
      setStations((current) => [
        ...current,
        { id: Date.now(), ...stationData },
      ]);
    }

    resetForm();
  };

  const handleEdit = (station) => {
    setEditingId(station.id);
    setFormData({
      name: station.name,
      parkingArea: station.parkingArea,
      chargerType: station.chargerType,
      power: String(station.power),
      status: station.status,
      price: String(station.price),
    });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this charging station?")) {
      setStations((current) =>
        current.filter((station) => station.id !== id)
      );
    }
  };

  const updateStatus = (id, status) => {
    setStations((current) =>
      current.map((station) =>
        station.id === id ? { ...station, status } : station
      )
    );
  };

  const availableCount = stations.filter(
    (station) => station.status === "Available"
  ).length;

  const inUseCount = stations.filter(
    (station) => station.status === "In Use"
  ).length;

  const maintenanceCount = stations.filter(
    (station) => station.status === "Maintenance"
  ).length;

  return (
    <div className="manage-ev">
      <div className="ev-header">
        <div>
          <h1>EV Charging Management</h1>
          <p>Manage electric vehicle charging stations across parking areas.</p>
        </div>

        <button
          className="ev-primary-btn"
          onClick={() => {
            resetForm();
            setShowForm(true);
          }}
        >
          + Add Charging Station
        </button>
      </div>

      <div className="ev-summary">
        <div className="ev-summary-card">
          <span>Total Stations</span>
          <strong>{stations.length}</strong>
        </div>
        <div className="ev-summary-card">
          <span>Available</span>
          <strong>{availableCount}</strong>
        </div>
        <div className="ev-summary-card">
          <span>In Use</span>
          <strong>{inUseCount}</strong>
        </div>
        <div className="ev-summary-card">
          <span>Maintenance</span>
          <strong>{maintenanceCount}</strong>
        </div>
      </div>

      {showForm && (
        <form className="ev-form" onSubmit={handleSubmit}>
          <h2>{editingId !== null ? "Edit Charging Station" : "Add Charging Station"}</h2>

          <div className="ev-form-grid">
            <label>
              Station Name
              <input
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="Enter station name"
                required
              />
            </label>

            <label>
              Parking Area
              <select
                value={formData.parkingArea}
                onChange={(e) =>
                  setFormData({ ...formData, parkingArea: e.target.value })
                }
              >
                <option>City Centre Parking</option>
                <option>Bus Stand Parking</option>
                <option>Market Square Parking</option>
              </select>
            </label>

            <label>
              Charger Type
              <select
                value={formData.chargerType}
                onChange={(e) =>
                  setFormData({ ...formData, chargerType: e.target.value })
                }
              >
                <option>Standard Charging</option>
                <option>Fast Charging</option>
              </select>
            </label>

            <label>
              Power (kW)
              <input
                type="number"
                min="0.1"
                step="0.1"
                value={formData.power}
                onChange={(e) =>
                  setFormData({ ...formData, power: e.target.value })
                }
                required
              />
            </label>

            <label>
              Price (₹ per kWh)
              <input
                type="number"
                min="0"
                step="0.01"
                value={formData.price}
                onChange={(e) =>
                  setFormData({ ...formData, price: e.target.value })
                }
                required
              />
            </label>

            <label>
              Status
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({ ...formData, status: e.target.value })
                }
              >
                <option>Available</option>
                <option>In Use</option>
                <option>Maintenance</option>
              </select>
            </label>
          </div>

          <div className="ev-form-actions">
            <button type="submit" className="ev-primary-btn">
              {editingId !== null ? "Save Changes" : "Add Station"}
            </button>
            <button type="button" className="ev-cancel-btn" onClick={resetForm}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="ev-controls">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search station or parking area..."
          aria-label="Search charging stations"
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          aria-label="Filter charging stations by status"
        >
          <option>All</option>
          <option>Available</option>
          <option>In Use</option>
          <option>Maintenance</option>
        </select>
      </div>

      <div className="ev-table-wrapper">
        <table className="ev-table">
          <thead>
            <tr>
              <th>Station</th>
              <th>Parking Area</th>
              <th>Charger Type</th>
              <th>Power</th>
              <th>Price / kWh</th>
              <th>Status</th>
              <th>Update Status</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredStations.map((station) => (
              <tr key={station.id}>
                <td><strong>{station.name}</strong></td>
                <td>{station.parkingArea}</td>
                <td>{station.chargerType}</td>
                <td>{station.power} kW</td>
                <td>₹{station.price}</td>
                <td>
                  <span
                    className={`ev-status ${station.status
                      .toLowerCase()
                      .replace(" ", "-")}`}
                  >
                    {station.status}
                  </span>
                </td>
                <td>
                  <select
                    value={station.status}
                    onChange={(e) => updateStatus(station.id, e.target.value)}
                    aria-label={`Update status for ${station.name}`}
                  >
                    <option>Available</option>
                    <option>In Use</option>
                    <option>Maintenance</option>
                  </select>
                </td>
                <td>
                  <div className="ev-row-actions">
                    <button onClick={() => handleEdit(station)}>Edit</button>
                    <button onClick={() => handleDelete(station.id)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredStations.length === 0 && (
          <p className="ev-empty">No charging stations found.</p>
        )}
      </div>
    </div>
  );
}

export default ManageEVCharging;