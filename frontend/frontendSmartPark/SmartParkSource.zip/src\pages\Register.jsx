import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Register.css";

function Register() {
const navigate = useNavigate();

const [formData, setFormData] = useState({
name: "",
email: "",
phone: "",
password: "",
confirmPassword: "",
});

const [showPassword, setShowPassword] = useState(false);
const [showConfirmPassword, setShowConfirmPassword] = useState(false);
const [message, setMessage] = useState("");
const [messageType, setMessageType] = useState("");
const [loading, setLoading] = useState(false);

function handleChange(event) {
const { name, value } = event.target;

setFormData((previous) => ({
  ...previous,
  [name]: value,
}));

setMessage("");

}

async function handleSubmit(event) {
event.preventDefault();
setMessage("");

if (formData.password.length < 8) {
  setMessage("Password must contain at least 8 characters.");
  setMessageType("error");
  return;
}

if (formData.password !== formData.confirmPassword) {
  setMessage("Passwords do not match.");
  setMessageType("error");
  return;
}

setLoading(true);

try {
  const response = await fetch(
    "http://127.0.0.1:8000/users/register",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: formData.name.trim(),
        email: formData.email.trim(),
        password: formData.password,
      }),
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      typeof data.detail === "string"
        ? data.detail
        : "Registration failed. Please check your details."
    );
  }

  setMessage("Account created successfully! Redirecting to login...");
  setMessageType("success");

  setTimeout(() => {
    navigate("/login");
  }, 1200);
} catch (error) {
  setMessage(
    error.message ||
      "Unable to connect to the backend. Make sure the backend is running."
  );
  setMessageType("error");
} finally {
  setLoading(false);
}

}

return (
<div className="register-page">
<section className="register-visual">
<Link to="/" className="register-brand">
🚗 SmartPark
</Link>

    <div className="register-visual-content">
      <div className="register-parking-symbol">P</div>

      <h1>Your journey to easier parking starts here.</h1>

      <p>
        Create your account to explore parking areas,
        reserve spaces, and manage your bookings in one place.
      </p>

      <div className="register-benefits">
        <span>✓ Quick parking reservations</span>
        <span>✓ Manage your bookings easily</span>
        <span>✓ Convenient parking experience</span>
      </div>
    </div>

    <p className="register-visual-footer">
      Smart parking. Smoother journeys.
    </p>
  </section>

  <section className="register-form-section">
    <div className="register-form-container">
      <Link to="/" className="register-mobile-brand">
        🚗 SmartPark
      </Link>

      <span className="register-eyebrow">GET STARTED</span>

      <h2>Create your account</h2>

      <p className="register-description">
        Enter your details to join SmartPark.
      </p>

      <form className="register-form" onSubmit={handleSubmit}>
        <div className="register-field">
          <label htmlFor="register-name">Full name</label>
          <input
            id="register-name"
            name="name"
            type="text"
            placeholder="Enter your full name"
            autoComplete="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="register-field">
          <label htmlFor="register-email">Email address</label>
          <input
            id="register-email"
            name="email"
            type="email"
            placeholder="you@example.com"
            autoComplete="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        <div className="register-field">
          <label htmlFor="register-phone">Phone number</label>
          <input
            id="register-phone"
            name="phone"
            type="tel"
            placeholder="Enter your phone number"
            autoComplete="tel"
            value={formData.phone}
            onChange={handleChange}
            pattern="[0-9]{10}"
            maxLength={10}
            title="Enter a 10-digit phone number"
            required
          />
        </div>

        <div className="register-field">
          <label htmlFor="register-password">Password</label>

          <div className="register-password-wrapper">
            <input
              id="register-password"
              name="password"
              type={showPassword ? "text" : "password"}
              placeholder="At least 8 characters"
              autoComplete="new-password"
              value={formData.password}
              onChange={handleChange}
              minLength={8}
              required
            />

            <button
              type="button"
              className="register-toggle-password"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
        </div>

        <div className="register-field">
          <label htmlFor="register-confirm-password">
            Confirm password
          </label>

          <div className="register-password-wrapper">
            <input
              id="register-confirm-password"
              name="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              placeholder="Re-enter your password"
              autoComplete="new-password"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
            />

            <button
              type="button"
              className="register-toggle-password"
              onClick={() =>
                setShowConfirmPassword(!showConfirmPassword)
              }
            >
              {showConfirmPassword ? "Hide" : "Show"}
            </button>
          </div>
        </div>

        {message && (
          <p
            className={`register-message ${messageType}`}
            role="status"
          >
            {message}
          </p>
        )}

        <button
          type="submit"
          className="register-submit-btn"
          disabled={loading}
        >
          {loading ? "Creating Account..." : "Create Account"}
          {!loading && <span> →</span>}
        </button>
      </form>

      <p className="register-login-text">
        Already have an account?{" "}
        <Link to="/login">Sign in</Link>
      </p>

      <Link to="/" className="register-home-link">
        ← Back to Home
      </Link>
    </div>
  </section>
</div>

);
}

export default Register;