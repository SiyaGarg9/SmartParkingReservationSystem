
import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import "./Navbar.css";

const API_URL = "http://127.0.0.1:8000";

function Navbar() {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);

  const token = localStorage.getItem("access_token");

  const headers = {
    Authorization: `Bearer ${token}`,
  };

  const fetchNotifications = async () => {
    if (!token) return;

    try {
      const response = await fetch(`${API_URL}/notifications/`, {
        headers,
      });

      if (!response.ok) return;

      const data = await response.json();
      setNotifications(data);

      const unread = data.filter(
        (notification) => !notification.is_read
      ).length;

      setUnreadCount(unread);
    } catch (error) {
      console.error("Notification error:", error);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [token]);

  const markAsRead = async (id) => {
    try {
      const response = await fetch(
        `${API_URL}/notifications/${id}/read`,
        {
          method: "PUT",
          headers,
        }
      );

      if (response.ok) {
        fetchNotifications();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch(
        `${API_URL}/notifications/read-all`,
        {
          method: "PUT",
          headers,
        }
      );

      if (response.ok) {
        fetchNotifications();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const deleteNotification = async (id) => {
    try {
      const response = await fetch(
        `${API_URL}/notifications/${id}`,
        {
          method: "DELETE",
          headers,
        }
      );

      if (response.ok) {
        fetchNotifications();
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <nav className="navbar">
      <NavLink to="/" className="navbar-logo">
        🚗 SmartPark
      </NavLink>

      <div className="navbar-links">
        <NavLink
          to="/"
          end
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Home
        </NavLink>

        <NavLink
          to="/search"
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Find Parking
        </NavLink>

        <NavLink
          to="/bookings"
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          My Bookings
        </NavLink>

        <NavLink
          to="/login"
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Login
        </NavLink>

        <NavLink
          to="/register"
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Register
        </NavLink>

        {token && (
          <div className="notification-wrapper">
            <button
              className="notification-bell"
              onClick={() => {
                setShowNotifications(!showNotifications);
                fetchNotifications();
              }}
              title="Notifications"
            >
              🔔
              {unreadCount > 0 && (
                <span className="notification-count">
                  {unreadCount > 99 ? "99+" : unreadCount}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="notification-dropdown">
                <div className="notification-header">
                  <h3>Notifications</h3>

                  {unreadCount > 0 && (
                    <button onClick={markAllAsRead}>
                      Mark all read
                    </button>
                  )}
                </div>

                {notifications.length === 0 ? (
                  <p className="no-notifications">
                    No notifications yet.
                  </p>
                ) : (
                  <div className="notification-list">
                    {notifications.map((notification) => (
                      <div
                        key={notification.notification_id}
                        className={`notification-item ${
                          notification.is_read ? "read" : "unread"
                        }`}
                      >
                        <div
                          className="notification-content"
                          onClick={() =>
                            !notification.is_read &&
                            markAsRead(notification.notification_id)
                          }
                        >
                          <strong>{notification.title}</strong>

                          <p>{notification.message}</p>

                          <small>
                            {new Date(
                              notification.created_at
                            ).toLocaleString()}
                          </small>
                        </div>

                        <button
                          className="delete-notification"
                          onClick={() =>
                            deleteNotification(
                              notification.notification_id
                            )
                          }
                          title="Delete notification"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
