
import { NavLink, Routes, Route, Navigate, Link } from "react-router-dom";
import "./AdminLayout.css";

import AdminDashboard from "./AdminDashboard";
import ManageParking from "./ManageParking";
import ManageSlots from "./ManageSlots";
import ManageBookings from "./ManageBookings";
import ManageUsers from "./ManageUsers";
import AdminReports from "./AdminReports";
import ManageEVCharging from "./ManageEVCharging";
import AdminSettings from "./AdminSettings";

function AdminLayout() {
  return (
    <div className="admin-layout">

      {/* SIDEBAR */}
      <aside className="admin-sidebar">

        <div className="admin-brand">
          <div className="admin-brand-icon">P</div>

          <div>
            <h2>SmartPark</h2>
            <p>Admin Panel</p>
          </div>
        </div>

        <nav className="admin-navigation">

          <p className="admin-nav-heading">MAIN MENU</p>

          <NavLink to="/admin" end className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">▦</span>
            Dashboard
          </NavLink>

          <NavLink to="/admin/parking" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">P</span>
            Parking Areas
          </NavLink>

          <NavLink to="/admin/slots" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">▤</span>
            Parking Slots
          </NavLink>

          <NavLink to="/admin/bookings" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">▣</span>
            Bookings
          </NavLink>

          <NavLink to="/admin/users" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">♙</span>
            Users
          </NavLink>

          <NavLink to="/admin/reports" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">▥</span>
            Reports
          </NavLink>

          <NavLink to="/admin/ev-charging" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">ϟ</span>
            EV Charging
          </NavLink>

          <NavLink to="/admin/settings" className={({ isActive }) =>
            `admin-nav-link ${isActive ? "active" : ""}`
          }>
            <span className="admin-nav-icon">⚙</span>
            Settings
          </NavLink>

          <Link to="/login" className="admin-back-link">
            ↗ Login to User Portal
          </Link>

        </nav>

        <div className="admin-sidebar-bottom">

          <Link to="/" className="admin-back-link">
            ← Back to Home
          </Link>

          <div className="admin-profile">
            <div className="admin-profile-avatar">A</div>

            <div>
              <strong>Administrator</strong>
              <span>Admin Account</span>
            </div>
          </div>

        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="admin-main">

        <header className="admin-topbar">
          <div>
            <h2>SmartPark Management</h2>
            <p>Manage your parking operations</p>
          </div>

          <div className="admin-online-status">
            <span></span>
            Admin
          </div>
        </header>

        <div className="admin-content">
          <Routes>
            <Route index element={<AdminDashboard />} />
            <Route path="parking" element={<ManageParking />} />
            <Route path="slots" element={<ManageSlots />} />
            <Route path="bookings" element={<ManageBookings />} />
            <Route path="users" element={<ManageUsers />} />
            <Route path="reports" element={<AdminReports />} />
            <Route path="ev-charging" element={<ManageEVCharging />} />
            <Route path="settings" element={<AdminSettings />} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        </div>

      </main>
    </div>
  );
}

export default AdminLayout;
