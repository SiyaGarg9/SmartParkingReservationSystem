
import { useEffect, useState } from "react";
import "./ManageSlots.css";

const API_URL = "http://127.0.0.1:8000";

const emptyForm = {
  slot_no: "",
  area_id: "",
  floorNo: "Ground",
  slot_type: "NORMAL",
  status: "AVAILABLE",
  is_ev_charging: false,
};

function ManageSlots() {
  const [slots, setSlots] = useState([]);
  const [areas, setAreas] = useState([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const [formData, setFormData] = useState(emptyForm);

  // -------------------------------------------------------
  // FETCH PARKING SLOTS AND PARKING AREAS
  // -------------------------------------------------------

  const fetchData = async () => {
    try {
      setError("");

      const [slotsResponse, areasResponse] = await Promise.all([
        fetch(`${API_URL}/parking/slots`),
        fetch(`${API_URL}/parking/areas`),
      ]);

      const slotsData = await slotsResponse.json();
      const areasData = await areasResponse.json();

      if (!slotsResponse.ok) {
        throw new Error("Unable to fetch parking slots.");
      }

      if (!areasResponse.ok) {
        throw new Error("Unable to fetch parking areas.");
      }

      setSlots(Array.isArray(slotsData) ? slotsData : []);
      setAreas(Array.isArray(areasData) ? areasData : []);
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // -------------------------------------------------------
  // GET PARKING AREA NAME
  // -------------------------------------------------------

  const getAreaName = (areaId) => {
    const area = areas.find(
      (item) => Number(item.area_id) === Number(areaId)
    );

    return area ? area.name : `Area #${areaId}`;
  };

  // -------------------------------------------------------
  // FILTER SLOTS
  // -------------------------------------------------------

  const filteredSlots = slots.filter((slot) => {
    const slotNumber = String(slot.slot_no || "").toLowerCase();
    const parkingArea = getAreaName(slot.area_id).toLowerCase();

    const matchesSearch =
      slotNumber.includes(search.toLowerCase()) ||
      parkingArea.includes(search.toLowerCase());

    const matchesStatus =
      statusFilter === "All" ||
      slot.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // -------------------------------------------------------
  // RESET FORM
  // -------------------------------------------------------

  const resetForm = () => {
    setFormData({
      ...emptyForm,
      area_id: areas.length > 0 ? String(areas[0].area_id) : "",
    });

    setEditingId(null);
    setShowForm(false);
  };

  // -------------------------------------------------------
  // ADD / UPDATE SLOT
  // -------------------------------------------------------

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.area_id) {
      alert("Please select a parking area.");
      return;
    }

    const payload = {
      slot_no: formData.slot_no.trim(),
      floorNo: formData.floorNo.trim(),
      slot_type: formData.slot_type,
      status: formData.status,
      is_ev_charging: formData.is_ev_charging,
    };

    try {
      setSaving(true);
      setError("");

      let response;

      if (editingId !== null) {
        // UPDATE EXISTING SLOT
        response = await fetch(
          `${API_URL}/parking/slots/${editingId}`,
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
          }
        );
      } else {
        // CREATE NEW SLOT
        response = await fetch(`${API_URL}/parking/slots`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            ...payload,
            area_id: Number(formData.area_id),
          }),
        });
      }

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "Unable to save parking slot."
        );
      }

      alert(
        editingId !== null
          ? "Parking slot updated successfully!"
          : "Parking slot added successfully!"
      );

      resetForm();
      await fetchData();
    } catch (err) {
      setError(err.message || "Unable to save parking slot.");
    } finally {
      setSaving(false);
    }
  };

  // -------------------------------------------------------
  // EDIT SLOT
  // -------------------------------------------------------

  const handleEdit = (slot) => {
    setEditingId(slot.slot_id);

    setFormData({
      slot_no: slot.slot_no,
      area_id: String(slot.area_id),
      floorNo: slot.floorNo || "Ground",
      slot_type: slot.slot_type,
      status: slot.status,
      is_ev_charging: slot.is_ev_charging,
    });

    setShowForm(true);
  };

  // -------------------------------------------------------
  // DELETE SLOT
  // -------------------------------------------------------

  const handleDelete = async (slotId) => {
    if (!window.confirm("Are you sure you want to delete this parking slot?")) {
      return;
    }

    try {
      setError("");

      const response = await fetch(
        `${API_URL}/parking/slots/${slotId}`,
        {
          method: "DELETE",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.detail || "Unable to delete parking slot."
        );
      }

      alert("Parking slot deleted successfully!");

      await fetchData();
    } catch (err) {
      setError(err.message || "Unable to delete parking slot.");
    }
  };

  // -------------------------------------------------------
  // CHANGE SLOT STATUS
  // -------------------------------------------------------

  const updateStatus = async (slot, newStatus) => {
    try {
      setError("");

      const payload = {
        slot_no: slot.slot_no,
        floorNo: slot.floorNo || "Ground",
        slot_type: slot.slot_type,
        status: newStatus,
        is_ev_charging: slot.is_ev_charging,
      };

      const response = await fetch(
        `${API_URL}/parking/slots/${slot.slot_id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.detail || "Unable to update slot status."
        );
      }

      await fetchData();
    } catch (err) {
      setError(err.message || "Unable to update slot status.");
    }
  };

  // -------------------------------------------------------
  // SLOT STATISTICS
  // -------------------------------------------------------

  const availableCount = slots.filter(
    (slot) => slot.status === "AVAILABLE"
  ).length;

  const occupiedCount = slots.filter(
    (slot) => slot.status === "OCCUPIED"
  ).length;

  const maintenanceCount = slots.filter(
    (slot) => slot.status === "MAINTENANCE"
  ).length;

  // -------------------------------------------------------
  // LOADING SCREEN
  // -------------------------------------------------------

  if (loading) {
    return (
      <div className="manage-slots">
        <h2>Loading parking slots...</h2>
      </div>
    );
  }

  // -------------------------------------------------------
  // MAIN PAGE
  // -------------------------------------------------------

  return (
    <div className="manage-slots">

      {/* HEADER */}

      <div className="slots-header">
        <div>
          <h1>Manage Parking Slots</h1>
          <p>Manage individual slots, availability, and EV charging.</p>
        </div>

        <button
          className="slots-primary-btn"
          onClick={() => {
            setFormData({
              ...emptyForm,
              area_id: areas.length > 0
                ? String(areas[0].area_id)
                : "",
            });

            setEditingId(null);
            setShowForm(true);
          }}
        >
          + Add Slot
        </button>
      </div>

      {/* ERROR MESSAGE */}

      {error && (
        <div className="admin-error">
          <p>{error}</p>
          <button onClick={fetchData}>Retry</button>
        </div>
      )}

      {/* SUMMARY CARDS */}

      <div className="slots-summary">
        <div className="slots-summary-card">
          <span>Total Slots</span>
          <strong>{slots.length}</strong>
        </div>

        <div className="slots-summary-card">
          <span>Available</span>
          <strong>{availableCount}</strong>
        </div>

        <div className="slots-summary-card">
          <span>Occupied</span>
          <strong>{occupiedCount}</strong>
        </div>

        <div className="slots-summary-card">
          <span>Maintenance</span>
          <strong>{maintenanceCount}</strong>
        </div>
      </div>

      {/* ADD / EDIT FORM */}

      {showForm && (
        <form className="slots-form" onSubmit={handleSubmit}>
          <h2>
            {editingId !== null ? "Edit Slot" : "Add New Slot"}
          </h2>

          <div className="slots-form-grid">

            <label>
              Slot Number
              <input
                value={formData.slot_no}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    slot_no: e.target.value,
                  })
                }
                placeholder="e.g. A01"
                required
              />
            </label>

            <label>
              Parking Area
              <select
                value={formData.area_id}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    area_id: e.target.value,
                  })
                }
                required
                disabled={editingId !== null}
              >
                {areas.map((area) => (
                  <option
                    key={area.area_id}
                    value={area.area_id}
                  >
                    {area.name}
                  </option>
                ))}
              </select>

              {editingId !== null && (
                <small>
                  Parking area cannot be changed using the current backend update API.
                </small>
              )}
            </label>

            <label>
              Floor Number
              <input
                value={formData.floorNo}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    floorNo: e.target.value,
                  })
                }
                placeholder="e.g. Ground"
                required
              />
            </label>

            <label>
              Slot Type
              <select
                value={formData.slot_type}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    slot_type: e.target.value,
                  })
                }
              >
                <option value="NORMAL">Normal</option>
                <option value="COMPACT">Compact</option>
                <option value="LARGE">Large</option>
                <option value="EV">EV</option>
              </select>
            </label>

            <label>
              Slot Status
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    status: e.target.value,
                  })
                }
              >
                <option value="AVAILABLE">Available</option>
                <option value="OCCUPIED">Occupied</option>
                <option value="MAINTENANCE">Maintenance</option>
              </select>
            </label>

            <label className="ev-checkbox">
              <input
                type="checkbox"
                checked={formData.is_ev_charging}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    is_ev_charging: e.target.checked,
                  })
                }
              />
              EV charging available
            </label>

          </div>

          <div className="slots-form-actions">
            <button
              type="submit"
              className="slots-primary-btn"
              disabled={saving}
            >
              {saving
                ? "Saving..."
                : editingId !== null
                  ? "Save Changes"
                  : "Add Slot"}
            </button>

            <button
              type="button"
              className="slots-cancel-btn"
              onClick={resetForm}
              disabled={saving}
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* SEARCH AND FILTER */}

      <div className="slots-filters">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search slot or parking area..."
          aria-label="Search slots"
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          aria-label="Filter slots by status"
        >
          <option value="All">All</option>
          <option value="AVAILABLE">Available</option>
          <option value="OCCUPIED">Occupied</option>
          <option value="MAINTENANCE">Maintenance</option>
        </select>
      </div>

      {/* SLOTS TABLE */}

      <div className="slots-table-wrapper">
        <table className="slots-table">

          <thead>
            <tr>
              <th>Slot</th>
              <th>Parking Area</th>
              <th>Slot Type</th>
              <th>EV Charging</th>
              <th>Status</th>
              <th>Change Status</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredSlots.map((slot) => (
              <tr key={slot.slot_id}>

                <td>
                  <strong>{slot.slot_no}</strong>
                </td>

                <td>{getAreaName(slot.area_id)}</td>

                <td>{slot.slot_type}</td>

                <td>
                  {slot.is_ev_charging ? "Yes" : "No"}
                </td>

                <td>
                  <span
                    className={`slot-status ${
                      slot.status.toLowerCase().replace(" ", "-")
                    }`}
                  >
                    {slot.status.charAt(0) +
                      slot.status.slice(1).toLowerCase()}
                  </span>
                </td>

                <td>
                  <select
                    value={slot.status}
                    onChange={(e) =>
                      updateStatus(slot, e.target.value)
                    }
                    aria-label={`Change status for ${slot.slot_no}`}
                  >
                    <option value="AVAILABLE">Available</option>
                    <option value="OCCUPIED">Occupied</option>
                    <option value="MAINTENANCE">Maintenance</option>
                  </select>
                </td>

                <td>
                  <div className="slots-row-actions">
                    <button onClick={() => handleEdit(slot)}>
                      Edit
                    </button>

                    <button onClick={() => handleDelete(slot.slot_id)}>
                      Delete
                    </button>
                  </div>
                </td>

              </tr>
            ))}
          </tbody>

        </table>

        {filteredSlots.length === 0 && (
          <p className="slots-empty">
            No parking slots found.
          </p>
        )}
      </div>

    </div>
  );
}

export default ManageSlots;
