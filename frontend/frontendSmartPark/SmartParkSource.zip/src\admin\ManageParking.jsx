
import { useEffect, useState } from "react";
import "./ManageParking.css";

const API_URL = "http://127.0.0.1:8000";

function ManageParking() {
  const [parkingAreas, setParkingAreas] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    name: "",
    location: "",
  });

  // API request helper
  const apiRequest = async (url, options = {}) => {
    const response = await fetch(`${API_URL}${url}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
    });

    const text = await response.text();
    let data = {};

    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }

    if (!response.ok) {
      throw new Error(
        data.detail || data.message || "Something went wrong."
      );
    }

    return data;
  };

  // Fetch parking areas and slots
  const fetchParkingData = async () => {
    try {
      setLoading(true);
      setError("");

      const [areas, slots] = await Promise.all([
        apiRequest("/parking/areas"),
        apiRequest("/parking/slots"),
      ]);

      const updatedAreas = areas.map((area) => {
        const areaSlots = slots.filter(
          (slot) => slot.area_id === area.area_id
        );

        const availableSlots = areaSlots.filter(
          (slot) => slot.status === "AVAILABLE"
        ).length;

        return {
          ...area,
          totalSlots: areaSlots.length,
          availableSlots: availableSlots,
        };
      });

      setParkingAreas(updatedAreas);
    } catch (err) {
      setError(err.message || "Unable to load parking areas.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchParkingData();
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const resetForm = () => {
    setFormData({
      name: "",
      location: "",
    });

    setEditingId(null);
    setShowForm(false);
  };

  // Add or update parking area
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.location.trim()) {
      alert("Please enter the parking area name and location.");
      return;
    }

    try {
      setSubmitting(true);

      const areaData = {
        name: formData.name.trim(),
        location: formData.location.trim(),
      };

      if (editingId !== null) {
        await apiRequest(`/parking/areas/${editingId}`, {
          method: "PUT",
          body: JSON.stringify(areaData),
        });

        alert("Parking area updated successfully!");
      } else {
        await apiRequest("/parking/areas", {
          method: "POST",
          body: JSON.stringify(areaData),
        });

        alert("Parking area added successfully!");
      }

      resetForm();
      await fetchParkingData();
    } catch (err) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // Edit parking area
  const handleEdit = (area) => {
    setEditingId(area.area_id);

    setFormData({
      name: area.name,
      location: area.location,
    });

    setShowForm(true);
  };

  // Delete parking area
  const handleDelete = async (area) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete ${area.name}?`
    );

    if (!confirmed) return;

    try {
      await apiRequest(`/parking/areas/${area.area_id}`, {
        method: "DELETE",
      });

      alert("Parking area deleted successfully!");

      await fetchParkingData();
    } catch (err) {
      alert(
        `Could not delete this parking area.\n${err.message}\n\nIt may contain parking slots or related bookings.`
      );
    }
  };

  if (loading) {
    return (
      <div className="manage-parking">
        <h2>Loading parking areas...</h2>
      </div>
    );
  }

  return (
    <div className="manage-parking">
      <div className="manage-parking-header">
        <div>
          <h1>Manage Parking Areas</h1>
          <p>Add and manage parking locations in SmartPark.</p>
        </div>

        <button
          className="add-parking-btn"
          onClick={() => {
            resetForm();
            setShowForm(true);
          }}
        >
          + Add Parking Area
        </button>
      </div>

      {error && (
        <div className="no-parking-areas">
          <p>{error}</p>
          <button
            className="add-parking-btn"
            onClick={fetchParkingData}
          >
            Try Again
          </button>
        </div>
      )}

      {showForm && (
        <form className="parking-form" onSubmit={handleSubmit}>
          <h2>
            {editingId !== null
              ? "Edit Parking Area"
              : "Add Parking Area"}
          </h2>

          <div className="parking-form-grid">
            <label>
              Parking Area Name
              <input
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter parking area name"
                required
              />
            </label>

            <label>
              Location
              <input
                name="location"
                value={formData.location}
                onChange={handleChange}
                placeholder="Enter location"
                required
              />
            </label>
          </div>

          <div className="parking-form-actions">
            <button
              type="submit"
              className="add-parking-btn"
              disabled={submitting}
            >
              {submitting
                ? "Saving..."
                : editingId !== null
                ? "Save Changes"
                : "Add Area"}
            </button>

            <button
              type="button"
              className="cancel-parking-btn"
              onClick={resetForm}
              disabled={submitting}
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {!error && (
        <>
          <div className="parking-area-count">
            Total Parking Areas:{" "}
            <strong>{parkingAreas.length}</strong>
          </div>

          <div className="parking-area-grid">
            {parkingAreas.map((area) => (
              <div
                className="parking-area-card"
                key={area.area_id}
              >
                <div className="parking-card-top">
                  <div className="parking-icon">P</div>
                  <span className="parking-area-status">
                    Active
                  </span>
                </div>

                <h2>{area.name}</h2>

                <p className="parking-location">
                  📍 {area.location}
                </p>

                <div className="parking-slot-details">
                  <div>
                    <span>Total Slots</span>
                    <strong>{area.totalSlots}</strong>
                  </div>

                  <div>
                    <span>Available</span>
                    <strong>{area.availableSlots}</strong>
                  </div>
                </div>

                <div className="parking-card-actions">
                  <button onClick={() => handleEdit(area)}>
                    Edit
                  </button>

                  <button onClick={() => handleDelete(area)}>
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>

          {parkingAreas.length === 0 && (
            <p className="no-parking-areas">
              No parking areas found.
            </p>
          )}
        </>
      )}
    </div>
  );
}

export default ManageParking;
