
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const API_URL = "http://127.0.0.1:8000";
const RATE_PER_HOUR = 100;

// Format a date using local time, without a timezone offset.
function formatLocalDateTime(dateValue) {
  return `${dateValue.getFullYear()}-${String(
    dateValue.getMonth() + 1
  ).padStart(2, "0")}-${String(
    dateValue.getDate()
  ).padStart(2, "0")}T${String(
    dateValue.getHours()
  ).padStart(2, "0")}:${String(
    dateValue.getMinutes()
  ).padStart(2, "0")}:00`;
}

function Booking() {
  const navigate = useNavigate();
  const routeLocation = useLocation();
  const parking = routeLocation.state;

  const [date, setDate] = useState(parking?.date || "");
  const [time, setTime] = useState(parking?.time || "");
  const [duration, setDuration] = useState("1");
  const [vehicle, setVehicle] = useState(parking?.vehicle || "Car");

  const [slots, setSlots] = useState([]);
  const [slotId, setSlotId] = useState("");
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);

  const [message, setMessage] = useState("");

  const totalAmount = RATE_PER_HOUR * Number(duration);

  // ========================================================
  // FETCH SLOTS BASED ON SELECTED DATE AND TIME
  // ========================================================

  useEffect(() => {
    if (!parking?.parkingId) return;

    // Clear the previously selected slot whenever booking
    // date, time or duration changes.
    setSlotId("");
    setSlots([]);

    if (!date || !time || !duration) {
      setLoadingSlots(false);
      return;
    }

    const startDateTime = new Date(`${date}T${time}:00`);
    const hours = Number(duration);

    if (
      Number.isNaN(startDateTime.getTime()) ||
      !Number.isFinite(hours) ||
      hours < 1
    ) {
      setLoadingSlots(false);
      return;
    }

    const endDateTime = new Date(
      startDateTime.getTime() + hours * 60 * 60 * 1000
    );

    const params = new URLSearchParams({
      start_time: formatLocalDateTime(startDateTime),
      end_time: formatLocalDateTime(endDateTime),
    });

    const controller = new AbortController();

    async function fetchSlots() {
      try {
        setLoadingSlots(true);
        setMessage("");

        const response = await fetch(
          `${API_URL}/parking/areas/${parking.parkingId}/slots?${params.toString()}`,
          {
            signal: controller.signal,
          }
        );

        if (!response.ok) {
          throw new Error("Unable to fetch available parking slots.");
        }

        const data = await response.json();

        setSlots(
          data.filter((slot) => slot.status === "AVAILABLE")
        );

      } catch (error) {
        if (error.name !== "AbortError") {
          setMessage(error.message);
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoadingSlots(false);
        }
      }
    }

    fetchSlots();

    return () => {
      controller.abort();
    };

  }, [parking?.parkingId, date, time, duration]);

  // ========================================================
  // CHECK PARKING SELECTION
  // ========================================================

  if (!parking) {
    return (
      <div style={{ maxWidth: "700px", margin: "60px auto", padding: "24px" }}>
        <h2>Choose a parking area first</h2>
        <p>Please select a parking area before proceeding.</p>

        <button onClick={() => navigate("/search")}>
          Find Parking
        </button>
      </div>
    );
  }

  // ========================================================
  // CREATE BOOKING
  // ========================================================

  async function handleBooking(event) {
    event.preventDefault();
    setMessage("");

    if (!date || !time || !slotId) {
      setMessage("Please select your date, time and parking slot.");
      return;
    }

    const startDateTime = new Date(`${date}T${time}:00`);
    const hours = Number(duration);

    if (
      Number.isNaN(startDateTime.getTime()) ||
      startDateTime <= new Date()
    ) {
      setMessage("Please select a future arrival date and time.");
      return;
    }

    if (!Number.isFinite(hours) || hours < 1) {
      setMessage("Please select a valid parking duration.");
      return;
    }

    const token = localStorage.getItem("user_access_token");
    const userId = localStorage.getItem("user_id");

    if (!token || !userId) {
      setMessage("Please log in before making a booking.");
      return;
    }

    const endDateTime = new Date(
      startDateTime.getTime() + hours * 60 * 60 * 1000
    );

    try {
      setBookingLoading(true);

      const response = await fetch(`${API_URL}/bookings`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          user_id: Number(userId),
          slot_id: Number(slotId),
          start_time: formatLocalDateTime(startDateTime),
          end_time: formatLocalDateTime(endDateTime),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "Booking failed. Please try again."
        );
      }

      const newBookingId = data.booking_id ?? data.id;

      if (!newBookingId) {
        setMessage(
          "Booking was created, but the Booking ID was not returned. Please check My Bookings before trying again."
        );
        return;
      }

      navigate("/payment", {
        state: {
          bookingId: newBookingId,
          amount: totalAmount,
          parkingName: parking.parkingName,
          location: parking.location,
          date,
          time,
          duration: hours,
          slotId,
          vehicle,
        },
      });

    } catch (error) {
      setMessage(error.message);
    } finally {
      setBookingLoading(false);
    }
  }

  // ========================================================
  // BOOKING FORM
  // ========================================================

  return (
    <div
      style={{
        maxWidth: "850px",
        margin: "40px auto",
        padding: "24px",
        color: "#173653",
      }}
    >
      <button onClick={() => navigate("/search")}>
        ← Back to Search
      </button>

      <h1 style={{ marginTop: "24px" }}>Complete Your Booking</h1>

      <p>
        Review your parking selection and choose your arrival details.
      </p>

      <div
        style={{
          padding: "24px",
          margin: "24px 0",
          border: "1px solid #dce5ef",
          borderRadius: "14px",
          background: "#f7faff",
        }}
      >
        <h2>{parking.parkingName}</h2>
        <p>{parking.location}</p>
        <p>Hourly rate: ₹{RATE_PER_HOUR}</p>
      </div>

      <form onSubmit={handleBooking}>
        <div style={{ display: "grid", gap: "18px" }}>

          <label>
            Arrival date

            <input
              type="date"
              min={new Date().toLocaleDateString("en-CA")}
              value={date}
              onChange={(event) => setDate(event.target.value)}
              required
              style={{
                display: "block",
                padding: "12px",
                width: "100%",
                marginTop: "6px",
              }}
            />
          </label>

          <label>
            Arrival time

            <input
              type="time"
              value={time}
              onChange={(event) => setTime(event.target.value)}
              required
              style={{
                display: "block",
                padding: "12px",
                width: "100%",
                marginTop: "6px",
              }}
            />
          </label>

          <label>
            Parking duration

            <select
              value={duration}
              onChange={(event) => setDuration(event.target.value)}
              style={{
                display: "block",
                padding: "12px",
                width: "100%",
                marginTop: "6px",
              }}
            >
              <option value="1">1 hour</option>
              <option value="2">2 hours</option>
              <option value="3">3 hours</option>
              <option value="4">4 hours</option>
              <option value="6">6 hours</option>
              <option value="8">8 hours</option>
            </select>
          </label>

          <label>
            Select parking slot

            <select
              value={slotId}
              onChange={(event) => setSlotId(event.target.value)}
              required
              disabled={!date || !time || loadingSlots || slots.length === 0}
              style={{
                display: "block",
                padding: "12px",
                width: "100%",
                marginTop: "6px",
              }}
            >
              <option value="">
                {loadingSlots
                  ? "Checking available slots..."
                  : !date || !time
                  ? "Select date and time first"
                  : slots.length === 0
                  ? "No slots available for this time"
                  : "Choose a parking slot"}
              </option>

              {slots.map((slot) => (
                <option key={slot.slot_id} value={slot.slot_id}>
                  {slot.slot_no}
                  {slot.is_ev_charging ? " (EV Charging)" : ""}
                </option>
              ))}
            </select>
          </label>

          <label>
            Vehicle type

            <select
              value={vehicle}
              onChange={(event) => setVehicle(event.target.value)}
              style={{
                display: "block",
                padding: "12px",
                width: "100%",
                marginTop: "6px",
              }}
            >
              <option value="Car">Car</option>
              <option value="Bike">Bike</option>
              <option value="EV">Electric vehicle</option>
            </select>
          </label>

        </div>

        <h3 style={{ marginTop: "24px" }}>
          Estimated total: ₹{totalAmount}
        </h3>

        <p style={{ color: "#666", fontSize: "14px" }}>
          ₹100 × {duration} hour(s)
        </p>

        {message && (
          <p role="alert" style={{ color: "#b42318" }}>
            {message}
          </p>
        )}

        <button
          type="submit"
          disabled={
            bookingLoading ||
            loadingSlots ||
            !slotId ||
            slots.length === 0
          }
          style={{
            marginTop: "16px",
            padding: "14px 22px",
            background: "#0879bf",
            color: "white",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          {bookingLoading ? "Processing..." : "Confirm Booking"}
        </button>

      </form>
    </div>
  );
}

export default Booking;
