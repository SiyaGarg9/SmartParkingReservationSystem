
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import "./MyBookings.css";

const API_URL = "http://127.0.0.1:8000";

function MyBookings() {
  const navigate = useNavigate();

  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [qrCodes, setQrCodes] = useState({});
  const [generatingQR, setGeneratingQR] = useState(null);
  const [qrError, setQrError] = useState("");

  // EXIT QR STATES
  const [exitQrCodes, setExitQrCodes] = useState({});
  const [exitQrLoading, setExitQrLoading] = useState(null);
  const [exitQrError, setExitQrError] = useState({});

  // Feedback states
  const [feedbackByBooking, setFeedbackByBooking] = useState({});
  const [feedbackDrafts, setFeedbackDrafts] = useState({});
  const [feedbackBusy, setFeedbackBusy] = useState(null);
  const [feedbackMessages, setFeedbackMessages] = useState({});

  // Fetch all user bookings
  useEffect(() => {
    async function fetchBookings() {
      try {
        const token = localStorage.getItem("access_token");
        const userId = localStorage.getItem("user_id");

        if (!token || !userId) {
          setError("Please log in to view your bookings.");
          return;
        }

        const response = await fetch(
          `${API_URL}/bookings/user/${userId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            typeof data.detail === "string"
              ? data.detail
              : "Unable to fetch bookings."
          );
        }

        const bookingList = Array.isArray(data) ? data : [];

        // Fetch payment and parking information
        const bookingsWithDetails = await Promise.all(
          bookingList.map(async (booking) => {
            let payment = null;
            let slot = null;
            let area = null;

            try {
              const paymentResponse = await fetch(
                `${API_URL}/payments/booking/${booking.booking_id}`
              );

              if (paymentResponse.ok) {
                payment = await paymentResponse.json();
              }
            } catch (err) {
              console.error("Payment fetch error:", err);
            }

            try {
              const areasResponse = await fetch(
                `${API_URL}/parking/areas`
              );

              if (areasResponse.ok) {
                const areasData = await areasResponse.json();

                const areas = Array.isArray(areasData)
                  ? areasData
                  : areasData.areas || areasData.data || [];

                for (const parkingArea of areas) {
                  const areaId =
                    parkingArea.area_id ?? parkingArea.id;

                  const slotsResponse = await fetch(
                    `${API_URL}/parking/areas/${areaId}/slots`
                  );

                  if (!slotsResponse.ok) continue;

                  const slotsData = await slotsResponse.json();

                  const slots = Array.isArray(slotsData)
                    ? slotsData
                    : slotsData.slots || slotsData.data || [];

                  const matchingSlot = slots.find(
                    (item) => item.slot_id === booking.slot_id
                  );

                  if (matchingSlot) {
                    slot = matchingSlot;
                    area = parkingArea;
                    break;
                  }
                }
              }
            } catch (err) {
              console.error("Parking location fetch error:", err);
            }

            return {
              ...booking,
              payment,
              slot,
              area,
            };
          })
        );

        setBookings(bookingsWithDetails);
      } catch (err) {
        setError(err.message || "Something went wrong.");
      } finally {
        setLoading(false);
      }
    }

    fetchBookings();
  }, []);

  // Fetch existing user feedback
  useEffect(() => {
    async function fetchMyFeedback() {
      try {
        const token = localStorage.getItem("access_token");

        if (!token) return;

        const response = await fetch(`${API_URL}/feedback/my`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) return;

        const data = await response.json();

        const feedbackList = Array.isArray(data)
          ? data
          : data.feedback || [];

        const feedbackMap = {};
        const drafts = {};

        feedbackList.forEach((item) => {
          feedbackMap[item.booking_id] = item;

          drafts[item.booking_id] = {
            rating: item.rating,
            comment: item.comment || "",
          };
        });

        setFeedbackByBooking(feedbackMap);
        setFeedbackDrafts(drafts);
      } catch (err) {
        console.error("Feedback fetch error:", err);
      }
    }

    fetchMyFeedback();
  }, []);

  // Generate or retrieve Entry QR code
  async function generateQR(bookingId) {
    try {
      setGeneratingQR(bookingId);
      setQrError("");

      const token = localStorage.getItem("access_token");

      if (!token) {
        throw new Error("Please log in again.");
      }

      let response = await fetch(
        `${API_URL}/qr/${bookingId}`
      );

      let data;

      if (response.ok) {
        data = await response.json();
      } else if (response.status === 404) {
        response = await fetch(
          `${API_URL}/qr/generate/${bookingId}`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        data = await response.json();

        if (!response.ok) {
          throw new Error(
            data.detail || "Unable to generate QR code."
          );
        }
      } else {
        data = await response.json();

        throw new Error(
          data.detail || "Unable to retrieve QR code."
        );
      }

      if (!data.qr_token) {
        throw new Error("QR token was not returned by the server.");
      }

      setQrCodes((previous) => ({
        ...previous,
        [bookingId]: data.qr_token,
      }));
    } catch (err) {
      setQrError(err.message);
    } finally {
      setGeneratingQR(null);
    }
  }

  // Retrieve the Exit QR generated by the admin
  async function fetchExitQR(bookingId) {
    try {
      setExitQrLoading(bookingId);

      setExitQrError((previous) => ({
        ...previous,
        [bookingId]: "",
      }));

      const response = await fetch(
        `${API_URL}/qr/${bookingId}`
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.detail || "Unable to retrieve Exit QR."
        );
      }

      if (!data.exit_qr_token) {
        throw new Error(
          "Your Exit QR has not been generated yet. Please contact the parking administrator."
        );
      }

      setExitQrCodes((previous) => ({
        ...previous,
        [bookingId]: data.exit_qr_token,
      }));
    } catch (err) {
      setExitQrError((previous) => ({
        ...previous,
        [bookingId]: err.message,
      }));
    } finally {
      setExitQrLoading(null);
    }
  }

  // Cancel booking
  async function cancelBooking(bookingId) {
    const confirmed = window.confirm(
      "Are you sure you want to cancel this booking?"
    );

    if (!confirmed) return;

    try {
      const token = localStorage.getItem("access_token");

      const response = await fetch(
        `${API_URL}/bookings/${bookingId}/cancel`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "Unable to cancel booking."
        );
      }

      setBookings((previousBookings) =>
        previousBookings.map((booking) =>
          booking.booking_id === bookingId
            ? { ...booking, status: "CANCELLED" }
            : booking
        )
      );

      setQrCodes((previous) => {
        const updated = { ...previous };
        delete updated[bookingId];
        return updated;
      });

      alert("Booking cancelled successfully!");
    } catch (error) {
      alert(error.message);
    }
  }

  // Update feedback form
  function updateFeedbackDraft(bookingId, field, value) {
    setFeedbackDrafts((previous) => ({
      ...previous,
      [bookingId]: {
        rating: previous[bookingId]?.rating || 5,
        comment: previous[bookingId]?.comment || "",
        [field]: value,
      },
    }));
  }

  // Submit or update feedback
  async function submitFeedback(bookingId) {
    try {
      const token = localStorage.getItem("user_access_token");

      if (!token) {
        throw new Error("Please log in again.");
      }

      const existingFeedback = feedbackByBooking[bookingId];

      const draft = feedbackDrafts[bookingId] || {
        rating: 5,
        comment: "",
      };

      setFeedbackBusy(bookingId);

      setFeedbackMessages((previous) => ({
        ...previous,
        [bookingId]: "",
      }));

      const url = existingFeedback
        ? `${API_URL}/feedback/${existingFeedback.feedback_id}`
        : `${API_URL}/feedback/?booking_id=${bookingId}`;

      const response = await fetch(url, {
        method: existingFeedback ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          rating: draft.rating,
          comment: draft.comment,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "Unable to submit feedback."
        );
      }

      const savedFeedback = data.feedback || data;

      setFeedbackByBooking((previous) => ({
        ...previous,
        [bookingId]: savedFeedback,
      }));

      setFeedbackDrafts((previous) => ({
        ...previous,
        [bookingId]: {
          rating: savedFeedback.rating ?? draft.rating,
          comment: savedFeedback.comment ?? draft.comment,
        },
      }));

      setFeedbackMessages((previous) => ({
        ...previous,
        [bookingId]: "Feedback saved successfully!",
      }));
    } catch (err) {
      setFeedbackMessages((previous) => ({
        ...previous,
        [bookingId]: err.message,
      }));
    } finally {
      setFeedbackBusy(null);
    }
  }

  // Delete feedback
  async function deleteFeedback(bookingId) {
    const existingFeedback = feedbackByBooking[bookingId];

    if (!existingFeedback) return;

    const confirmed = window.confirm(
      "Are you sure you want to delete this feedback?"
    );

    if (!confirmed) return;

    try {
      const token = localStorage.getItem("access_token");

      setFeedbackBusy(bookingId);

      const response = await fetch(
        `${API_URL}/feedback/${existingFeedback.feedback_id}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.detail || "Unable to delete feedback."
        );
      }

      setFeedbackByBooking((previous) => {
        const updated = { ...previous };
        delete updated[bookingId];
        return updated;
      });

      setFeedbackDrafts((previous) => ({
        ...previous,
        [bookingId]: {
          rating: 5,
          comment: "",
        },
      }));

      setFeedbackMessages((previous) => ({
        ...previous,
        [bookingId]: "Feedback deleted successfully.",
      }));
    } catch (err) {
      setFeedbackMessages((previous) => ({
        ...previous,
        [bookingId]: err.message,
      }));
    } finally {
      setFeedbackBusy(null);
    }
  }

  const upcomingBookings = bookings.filter(
    (booking) =>
      booking.status !== "CANCELLED" &&
      new Date(booking.start_time) >= new Date()
  );

  const pastBookings = bookings.filter(
    (booking) =>
      booking.status === "CANCELLED" ||
      new Date(booking.start_time) < new Date()
  );

  // Display individual booking
  function renderBooking(booking) {
    const payment = booking.payment;
    const slot = booking.slot;
    const area = booking.area;

    const qrToken = qrCodes[booking.booking_id];

    const canGenerateQR =
      booking.status === "BOOKED" &&
      payment?.payment_status === "SUCCESS";

    const canGiveFeedback =
      booking.status === "IN_PROGRESS" ||
      booking.status === "COMPLETED";

    const feedbackDraft = feedbackDrafts[booking.booking_id] || {
      rating: 5,
      comment: "",
    };

    const existingFeedback = feedbackByBooking[booking.booking_id];

    return (
      <article className="booking-card" key={booking.booking_id}>
        <div className="booking-card-top">
          <div className="booking-icon">P</div>

          <div className="booking-title">
            <h3>Parking Reservation</h3>
            <p>
              Parking Slot: {slot?.slot_no || booking.slot_id}
            </p>
          </div>

          <span
            className={`booking-status ${
              booking.status === "CANCELLED"
                ? "status-cancelled"
                : "status-confirmed"
            }`}
          >
            {booking.status}
          </span>
        </div>

        <div className="booking-details">
          <div>
            <span className="detail-label">Parking Area</span>
            <strong>{area?.name || "Not available"}</strong>
          </div>

          <div>
            <span className="detail-label">Location</span>
            <strong>{area?.location || "Not available"}</strong>
          </div>

          <div>
            <span className="detail-label">Slot Number</span>
            <strong>{slot?.slot_no || booking.slot_id}</strong>
          </div>

          <div>
            <span className="detail-label">Floor</span>
            <strong>
              {slot?.floorNo || slot?.floorno || "Not available"}
            </strong>
          </div>

          <div>
            <span className="detail-label">Slot Type</span>
            <strong>{slot?.slot_type || "Not available"}</strong>
          </div>

          <div>
            <span className="detail-label">EV Charging</span>
            <strong>
              {slot
                ? slot.is_ev_charging
                  ? "Available"
                  : "Not available"
                : "Not available"}
            </strong>
          </div>

          <div>
            <span className="detail-label">Arrival</span>
            <strong>
              {new Date(booking.start_time).toLocaleString()}
            </strong>
          </div>

          <div>
            <span className="detail-label">Departure</span>
            <strong>
              {new Date(booking.end_time).toLocaleString()}
            </strong>
          </div>

          <div>
            <span className="detail-label">User ID</span>
            <strong>{booking.user_id}</strong>
          </div>

          <div>
            <span className="detail-label">Booking ID</span>
            <strong>{booking.booking_id}</strong>
          </div>
        </div>

        {/* Payment Information */}
        <div
          style={{
            marginTop: "20px",
            padding: "18px",
            background: "#f4f8fc",
            borderRadius: "10px",
            border: "1px solid #dce5ef",
          }}
        >
          <h3 style={{ marginTop: 0 }}>Payment Details</h3>

          {payment ? (
            <>
              <p>
                <strong>Payment Status:</strong>{" "}
                {payment.payment_status}
              </p>

              <p>
                <strong>Amount Paid:</strong> ₹{payment.amount}
              </p>

              <p>
                <strong>Payment Method:</strong>{" "}
                {payment.payment_method}
              </p>

              <p>
                <strong>Transaction ID:</strong>{" "}
                {payment.transaction_id}
              </p>

              <p>
                <strong>Payment Date:</strong>{" "}
                {payment.payment_time
                  ? new Date(payment.payment_time).toLocaleString()
                  : "Not available"}
              </p>
            </>
          ) : (
            <p style={{ color: "#b42318" }}>Not Paid</p>
          )}
        </div>

        {/* Entry QR Section */}
        {canGenerateQR && (
          <div
            style={{
              marginTop: "20px",
              padding: "20px",
              background: "#f4f8fc",
              borderRadius: "10px",
              border: "1px solid #dce5ef",
              textAlign: "center",
            }}
          >
            <h3>Parking Entry QR Code</h3>

            <p>
              Show this QR code at the parking entrance for
              booking verification.
            </p>

            {!qrToken ? (
              <button
                className="find-more-btn"
                onClick={() => generateQR(booking.booking_id)}
                disabled={generatingQR === booking.booking_id}
              >
                {generatingQR === booking.booking_id
                  ? "Loading QR..."
                  : "View QR Code"}
              </button>
            ) : (
              <>
                <div
                  style={{
                    display: "inline-block",
                    background: "#ffffff",
                    padding: "15px",
                    borderRadius: "10px",
                    margin: "10px",
                  }}
                >
                  <QRCodeSVG
                    value={qrToken}
                    size={200}
                    level="H"
                    includeMargin
                  />
                </div>

                <p>
                  <strong>Booking ID:</strong>{" "}
                  {booking.booking_id}
                </p>

                <p style={{ fontSize: "12px", color: "#64748b" }}>
                  Keep this QR code ready when you arrive.
                </p>

                <button
                  className="find-more-btn"
                  onClick={() => window.print()}
                >
                  Print QR Code
                </button>
              </>
            )}

            {qrError && (
              <p style={{ color: "#b42318", marginTop: "10px" }}>
                {qrError}
              </p>
            )}
          </div>
        )}

        {/* Entry Approved and Exit QR Section */}
        {booking.status === "IN_PROGRESS" && (
          <div
            style={{
              marginTop: "20px",
              padding: "20px",
              background: "#f0fdf4",
              borderRadius: "10px",
              border: "1px solid #bbf7d0",
              textAlign: "center",
            }}
          >
            <h3>✓ Parking Entry Approved</h3>

            <p>Your vehicle entry has been recorded successfully.</p>

            <h3>Parking Exit QR Code</h3>

            <p>
              Show this QR code to the administrator when leaving
              the parking area.
            </p>

            {!exitQrCodes[booking.booking_id] ? (
              <button
                className="find-more-btn"
                onClick={() => fetchExitQR(booking.booking_id)}
                disabled={exitQrLoading === booking.booking_id}
              >
                {exitQrLoading === booking.booking_id
                  ? "Loading Exit QR..."
                  : "View Exit QR"}
              </button>
            ) : (
              <>
                <div
                  style={{
                    display: "inline-block",
                    background: "#ffffff",
                    padding: "15px",
                    borderRadius: "10px",
                    margin: "10px",
                  }}
                >
                  <QRCodeSVG
                    value={exitQrCodes[booking.booking_id]}
                    size={200}
                    level="H"
                    includeMargin
                  />
                </div>

                <p>
                  <strong>Booking ID:</strong>{" "}
                  {booking.booking_id}
                </p>

                <p style={{ fontSize: "12px", color: "#64748b" }}>
                  Keep this QR code ready when leaving.
                </p>

                <button
                  className="find-more-btn"
                  onClick={() => window.print()}
                >
                  Print Exit QR
                </button>
              </>
            )}

            {exitQrError[booking.booking_id] && (
              <p style={{ color: "#b42318", marginTop: "10px" }}>
                {exitQrError[booking.booking_id]}
              </p>
            )}
          </div>
        )}

        {/* Ratings and Feedback */}
        {canGiveFeedback && (
          <div
            style={{
              marginTop: "20px",
              padding: "20px",
              background: "#fffaf0",
              border: "1px solid #f1dfb8",
              borderRadius: "12px",
            }}
          >
            <h3 style={{ marginTop: 0 }}>
              Rate Your Parking Experience
            </h3>

            {existingFeedback && (
              <p style={{ color: "#15803d" }}>
                You have already submitted feedback. You can update it below.
              </p>
            )}

            <p style={{ marginBottom: "8px" }}>
              Your Rating:
            </p>

            <div
              style={{
                display: "flex",
                gap: "8px",
                marginBottom: "15px",
              }}
            >
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() =>
                    updateFeedbackDraft(
                      booking.booking_id,
                      "rating",
                      star
                    )
                  }
                  style={{
                    border: "none",
                    background: "transparent",
                    fontSize: "30px",
                    cursor: "pointer",
                    color:
                      star <= feedbackDraft.rating
                        ? "#f5a623"
                        : "#cbd5e1",
                  }}
                >
                  ★
                </button>
              ))}
            </div>

            <textarea
              placeholder="Share your parking experience..."
              value={feedbackDraft.comment}
              onChange={(e) =>
                updateFeedbackDraft(
                  booking.booking_id,
                  "comment",
                  e.target.value
                )
              }
              maxLength={1000}
              rows={3}
              style={{
                width: "100%",
                padding: "12px",
                border: "1px solid #dce5ef",
                borderRadius: "8px",
                resize: "vertical",
                boxSizing: "border-box",
                fontFamily: "inherit",
              }}
            />

            <div
              style={{
                display: "flex",
                gap: "10px",
                flexWrap: "wrap",
                marginTop: "12px",
              }}
            >
              <button
                className="find-more-btn"
                onClick={() => submitFeedback(booking.booking_id)}
                disabled={feedbackBusy === booking.booking_id}
              >
                {feedbackBusy === booking.booking_id
                  ? "Saving..."
                  : existingFeedback
                  ? "Update Feedback"
                  : "Submit Feedback"}
              </button>

              {existingFeedback && (
                <button
                  className="cancel-booking-btn"
                  onClick={() => deleteFeedback(booking.booking_id)}
                  disabled={feedbackBusy === booking.booking_id}
                >
                  Delete Feedback
                </button>
              )}
            </div>

            {feedbackMessages[booking.booking_id] && (
              <p style={{ marginTop: "12px" }}>
                {feedbackMessages[booking.booking_id]}
              </p>
            )}
          </div>
        )}

        {/* Indoor Navigation */}
        {(booking.status === "BOOKED" ||
          booking.status === "IN_PROGRESS") && (
          <div className="booking-card-bottom">
            <button
              className="find-more-btn"
              onClick={() =>
                navigate(`/navigation/${booking.booking_id}`)
              }
            >
              Navigate to Slot →
            </button>
          </div>
        )}

        {/* Cancel Booking */}
        {booking.status !== "CANCELLED" &&
          booking.status !== "IN_PROGRESS" && (
            <div className="booking-card-bottom">
              <button
                className="cancel-booking-btn"
                onClick={() => cancelBooking(booking.booking_id)}
              >
                Cancel booking
              </button>
            </div>
          )}
      </article>
    );
  }

  return (
    <div className="my-bookings-page">
      <section className="bookings-hero">
        <span className="bookings-eyebrow">
          YOUR PARKING, ORGANIZED
        </span>

        <h1>My Bookings</h1>

        <p>
          View and manage your SmartPark reservations in one place.
        </p>
      </section>

      <section className="bookings-content">
        {loading ? (
          <p>Loading your bookings...</p>
        ) : error ? (
          <p style={{ color: "#b42318" }}>{error}</p>
        ) : (
          <>
            <div className="bookings-summary">
              <div className="summary-card">
                <span>Total bookings</span>
                <strong>{bookings.length}</strong>
              </div>

              <div className="summary-card">
                <span>Upcoming</span>
                <strong>{upcomingBookings.length}</strong>
              </div>

              <div className="summary-card">
                <span>Past / cancelled</span>
                <strong>{pastBookings.length}</strong>
              </div>
            </div>

            <div className="bookings-section-heading">
              <div>
                <h2>Your reservations</h2>
                <p>Keep track of your parking plans.</p>
              </div>

              <button
                className="find-more-btn"
                onClick={() => navigate("/search")}
              >
                + Find Parking
              </button>
            </div>

            {bookings.length === 0 ? (
              <div className="empty-bookings">
                <div className="empty-bookings-icon">🚗</div>

                <h3>No bookings yet</h3>

                <p>
                  Your reservations will appear here once you book
                  a parking space.
                </p>

                <button
                  className="find-more-btn"
                  onClick={() => navigate("/search")}
                >
                  Explore Parking
                </button>
              </div>
            ) : (
              <>
                {upcomingBookings.length > 0 && (
                  <div className="booking-group">
                    <h3>Upcoming bookings</h3>
                    {upcomingBookings.map(renderBooking)}
                  </div>
                )}

                {pastBookings.length > 0 && (
                  <div className="booking-group">
                    <h3>Past and cancelled bookings</h3>
                    {pastBookings.map(renderBooking)}
                  </div>
                )}
              </>
            )}
          </>
        )}
      </section>
    </div>
  );
}

export default MyBookings;
